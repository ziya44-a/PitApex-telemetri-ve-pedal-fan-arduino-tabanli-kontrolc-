# LED araç ayarları – uygulama notları

TC, ABS, BB (Brake Bias), MAP (ECU Map) ve TC2 için bağımsız açma/kapatma ve test düğmeleri eklendi. Süre 0,5–8 saniye arasında ayarlanabilir. LED önceliği: yan araç > bayrak > ayar değişimi > vites.

ÖNEMLİ: Bu sürümde LED kontrolcüsü `engine.snap['t']` içindeki `tc_level`, `abs_level`, `brake_bias`, `ecu_map`, `tc2_level` gibi **gerçekten sağlanan** alanları okur. Mevcut pedal motoru telemetri adaptörleri bu alanların hepsini üretmiyor. Bu nedenle oyun içi otomatik tetikleme, ilgili oyun adaptörlerine doğrulanmış alan eşlemeleri eklenene kadar çalışmayabilir. ABS/TC aktivasyon sinyalleri ayar seviyesi yerine kullanılmaz.

Test: Python compileall başarılı; 5 etiketin 8x8 piksel üretimi ve canlı veri filtreleme temel testi başarılı. Gerçek Windows, oyun ve Arduino testi yapılmadı.
