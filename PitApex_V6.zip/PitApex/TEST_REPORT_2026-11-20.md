# PitApex – test ve kapsam raporu (20.11.2026)

## Doğrulananlar
- Python kaynakları: `python -m compileall -q .` başarılı.
- Otomatik birim testleri: `PYTHONPATH=. python -m unittest discover -s tests -p 'test_*.py' -q` → **275 test, OK**.
- Ana navigasyon: Donanım ve Telemetri/Kayıtlar olarak iki satırda gruplandı; sekme indeksleri ve son sekme tercihi korundu.
- LED animasyon ve LED sıfırlama bölümlerinin başlıkları sadeleştirildi.

## Sınırlar ve açık işler
- `python -m unittest tests.smoke_ui -q` başarısız: testin sahte tkinter paketi `colorchooser` sağlamıyor. Bu sonuç gerçek Windows Tk arayüzünün bozuk olduğunu kanıtlamaz; fakat GUI açılışının test edildiği de söylenemez.
- Gerçek Arduino, MAX7219, ACC, AC, LMU ve iRacing çalıştırılmadı. Oyun içi bayrak/yan araç telemetrisinin otomatik LED'e ulaşması doğrulanmadı.
- Eski güncelleme paketlerindeki her talebin eksiksiz uygulandığı doğrulanmadı. Özellikle telemetri entegrasyonu, overlay exclusive-fullscreen uyumu, dosya kilidi ve uzun süreli veri kalıcılığı gerçek ortam testine ihtiyaç duyuyor.
- RGB renkler MAX7219 tek renkli donanımda gösterilemez.
- Kaynakta bulunan testler önemli bir temel sağlar ancak tüm gereksinimlerin tamamlandığı anlamına gelmez.

## Dağıtım
Bu sürüm **test edilmiş kaynak kodu güncellemesi** olarak sunulur, donanım ve oyunlar üzerinde doğrulanmış final sürüm olarak değil.
