"""Radar: esikler, renk gecisi, tam onumuzdeki arac filtresi ve cizim."""
import math
import os
import sys
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from core import proximity_radar as pr  # noqa: E402
from core.models import TelemetryFrame  # noqa: E402
from tests.test_overlay import OverlayBase  # noqa: E402
from ui import overlays_page as op  # noqa: E402
from ui import radar_art as art  # noqa: E402


def hex_rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


class ThresholdAndColorTests(unittest.TestCase):
    def test_threat_ratio_boundaries(self):
        self.assertIsNone(pr.threat_ratio(10.01))
        self.assertIsNone(pr.threat_ratio(20))
        self.assertEqual(pr.threat_ratio(10.0), 0.0)           # 10 m: sari baslangici
        self.assertAlmostEqual(pr.threat_ratio(7.5), 0.5)
        self.assertEqual(pr.threat_ratio(5.0), 1.0)            # 5 m: tam kirmizi
        self.assertEqual(pr.threat_ratio(2.0), 1.0)
        self.assertIsNone(pr.threat_ratio(None))

    def test_color_is_yellow_at_10m_red_at_5m_and_transitions(self):
        self.assertEqual(hex_rgb(art.threat_hex(10.0)), art.YELLOW)
        self.assertEqual(hex_rgb(art.threat_hex(5.0)), art.RED)
        self.assertEqual(hex_rgb(art.threat_hex(3.0)), art.RED)
        self.assertEqual(hex_rgb(art.threat_hex(7.5)), art.ORANGE)
        # renk gecisli: yaklastikca yesil kanal surekli azalir (sari -> turuncu -> kirmizi), ani sicrama yok
        greens = [hex_rgb(art.threat_hex(d / 10.0))[1] for d in range(100, 49, -1)]
        self.assertEqual(greens, sorted(greens, reverse=True))
        self.assertLessEqual(max(a - b for a, b in zip(greens, greens[1:])), 6)
        self.assertEqual(art.threat_hex(12.0), art.NEUTRAL_CAR)   # 10 m'den uzak: uyari rengi yok

    def test_sector_arcs_run_from_yellow_at_10m_to_red_near_5m(self):
        arcs = art.sector_arcs(4.2)
        self.assertEqual(arcs[0], (10.0, art.to_hex(art.YELLOW)))
        self.assertEqual(hex_rgb(arcs[-1][1]), art.RED)
        radii = [r for r, _ in arcs]
        self.assertEqual(radii, sorted(radii, reverse=True))
        self.assertEqual(min(radii), 4.0)                          # en yakin araca kadar
        self.assertEqual(art.sector_arcs(10.0), [(10.0, art.to_hex(art.YELLOW))])
        self.assertEqual(art.sector_arcs(10.5), [])
        self.assertEqual(art.sector_arcs(None), [])


def frame(cars, x0=0.0):
    f = TelemetryFrame(game="ACC", live=True, track_id="t", speed_kmh=120.0)
    f.cars = [{"x": x0, "z": 0.0, "me": True, "pit": False, "p": None}] + \
             [{"x": x0 + dx, "z": dz, "me": False, "pit": False, "p": None} for dx, dz in cars]
    return f


def tracker_with_heading(cars):
    """Oyuncu +x yonunde giderken: ileri = +x, sag = +z. Dondurulen: hedef listesi."""
    t = pr.RadarTracker()
    t.calculate(frame([]), now=100.0)
    return t.calculate(frame(cars, x0=2.0), now=100.1)


class FrontFilterTests(unittest.TestCase):
    def test_car_directly_ahead_hidden_beyond_5m(self):
        self.assertEqual(tracker_with_heading([(8.0, 0.0)]), [])
        self.assertEqual(tracker_with_heading([(5.5, 1.0)]), [])
        self.assertEqual(tracker_with_heading([(15.0, -2.0)]), [])

    def test_car_directly_ahead_shown_within_5m(self):
        out = tracker_with_heading([(4.5, 0.0)])
        self.assertEqual(len(out), 1)
        self.assertAlmostEqual(out[0][2], 4.5)
        self.assertEqual(len(tracker_with_heading([(5.0, 0.0)])), 1)       # tam 5 m dahil

    def test_front_lane_boundary(self):
        self.assertEqual(tracker_with_heading([(8.0, 2.5)]), [])            # serit genisligi sinirinda: gizli
        self.assertEqual(len(tracker_with_heading([(8.0, 2.6)])), 1)        # yan seritte one dogru: gorunur

    def test_side_and_rear_cars_unaffected(self):
        out = tracker_with_heading([(0.0, 3.0), (-8.0, 0.0), (-3.0, -3.0), (0.0, -9.0)])
        self.assertEqual(len(out), 4)

    def test_range_and_pit_rules_unchanged(self):
        self.assertEqual(tracker_with_heading([(-21.0, 0.0)]), [])
        f = frame([(0.0, 3.0)], x0=2.0)
        f.cars[1]["pit"] = True
        t = pr.RadarTracker()
        t.calculate(frame([]), now=100.0)
        self.assertEqual(t.calculate(f, now=100.1), [])

    def test_sector_mapping_unchanged(self):
        out = tracker_with_heading([(0.0, 3.0)])         # sag taraf (+z) -> sektor 2
        self.assertEqual(out[0][3], 2)
        out = tracker_with_heading([(-6.0, 0.0)])        # arka -> sektor 4
        self.assertEqual(out[0][3], 4)


class ArtTests(unittest.TestCase):
    def test_car_shapes_have_full_detail_and_no_key_color(self):
        shapes = art.car_shapes(100, 100, 46, 19, art.PLAYER_CAR)
        self.assertGreaterEqual(len(shapes), 12)                  # golge, 4 tekerlek, kanat, govde, cam, tavan, farlar...
        for s in shapes:
            self.assertEqual(len(s["points"]) % 2, 0)
            self.assertNotEqual(s["fill"].lower(), op.TRANSPARENT_KEY)
        xs = [v for s in shapes for v in s["points"][0::2]]
        ys = [v for s in shapes for v in s["points"][1::2]]
        self.assertLessEqual(max(ys) - min(ys), 46 * 1.2)         # arac olculeri asilmaz
        self.assertLessEqual(max(xs) - min(xs), 19 * 1.3)

    def test_shade_accepts_short_hex(self):
        self.assertEqual(art.shade("#fff", 0.5), art.shade("#ffffff", 0.5))

    def test_tiny_car_drops_details_but_still_draws(self):
        shapes = art.car_shapes(50, 50, 16, 7, "#aab3bf")
        self.assertTrue(3 <= len(shapes) < 12)

    def test_body_outline_is_symmetric_and_smooth(self):
        body = art.chaikin(art._BODY, 2)
        self.assertGreater(len(body), len(art._BODY) * 3)
        self.assertAlmostEqual(sum(u for u, _ in body), 0.0, places=6)


class RadarOverlayTests(OverlayBase):
    def drawn(self, targets, size=(410, 410)):
        w = self.open("radar")
        w.canvas.w, w.canvas.h = size
        w._draw_radar(targets)
        return w, w.canvas.items

    @staticmethod
    def texts(items):
        return [i[2]["text"] for i in items if i[0] == "text"]

    @staticmethod
    def arc_lines(items):
        return [i for i in items if i[0] == "line" and i[2].get("width") == 3 and i[2].get("capstyle") == "round"]

    def test_no_primitive_uses_the_transparent_key_color(self):
        _w, items = self.drawn([(-2.0, -3.0, 3.6, 5), (6.0, 2.0, 6.3, 2)])
        for _k, _a, o in items:
            for opt in ("fill", "outline"):
                self.assertNotEqual((o.get(opt) or "").lower(), op.TRANSPARENT_KEY)

    def test_rings_at_5_10_20_with_colors(self):
        _w, items = self.drawn([])
        outlines = {i[2]["outline"] for i in items if i[0] == "oval" and i[2].get("outline") != art.SHADOW}
        self.assertTrue({"#ff4a40", "#ffd60a"} <= outlines)
        self.assertTrue({"5 m", "10 m", "20 m"} <= set(self.texts(items)))

    def test_warning_arcs_follow_gradient_yellow_to_red(self):
        _w, items = self.drawn([(0.0, -3.0, 3.0, 4)])              # 3 m arkada -> kirmizi bolge
        colors = [hex_rgb(i[2]["fill"]) for i in self.arc_lines(items)]
        self.assertEqual(colors[0], art.YELLOW)                    # en dis yay (10 m) sari
        self.assertEqual(colors[-1], art.RED)                      # en ic yaylar kirmizi
        mids = {c for c in colors if c not in (art.YELLOW, art.RED)}
        self.assertTrue(mids)                                       # aradaki turuncu tonlar var (gecis)

    def test_far_targets_have_no_warning_arcs_and_neutral_color(self):
        _w, items = self.drawn([(0.0, -14.0, 14.0, 4)])
        self.assertEqual(self.arc_lines(items), [])
        bodies = [i[2]["fill"] for i in items if i[0] == "poly"]
        self.assertIn(art.NEUTRAL_CAR, bodies)

    def test_threatening_car_body_matches_its_distance_color(self):
        _w, items = self.drawn([(3.0, 0.0, 7.5, 2)])
        bodies = [i[2]["fill"] for i in items if i[0] == "poly"]
        self.assertIn(art.threat_hex(7.5), bodies)

    def test_nearest_readout_shows_distance_and_direction(self):
        _w, items = self.drawn([(-2.0, -3.5, 4.0, 5), (6.0, 2.0, 6.3, 2)])
        t = self.texts(items)
        self.assertIn("4.0 m", t)
        self.assertIn("SOL ARKA", t)
        self.assertNotIn("6.3 m", t)                                # sadece en yakin: arac ustu etiket karmasasi yok

    def test_clear_and_waiting_states(self):
        _w, items = self.drawn([])
        self.assertIn("TEMİZ", self.texts(items))
        _w2, items2 = self.drawn(None)
        self.assertIn("VERİ BEKLENİYOR", self.texts(items2))
        self.assertEqual(self.arc_lines(items2), [])

    def test_player_car_drawn_last_in_green(self):
        _w, items = self.drawn([(3.0, 0.0, 3.0, 2)])
        polys = [i for i in items if i[0] == "poly"]
        self.assertTrue(polys[-1][2]["fill"] in {s["fill"] for s in art.car_shapes(0, 0, 40, 18, art.PLAYER_CAR)})

    def test_font_has_fallback_and_scales_with_window(self):
        w, items = self.drawn([(0.0, -3.0, 3.0, 4)])
        fam, weight = w._radar_family()
        self.assertTrue(fam)
        big = [i[2]["font"][1] for i in items if i[0] == "text" and i[2]["text"] == "3.0 m"][0]
        _w2, items2 = self.drawn([(0.0, -3.0, 3.0, 4)], size=(150, 150))
        small = [i[2]["font"][1] for i in items2 if i[0] == "text" and i[2]["text"] == "3.0 m"][0]
        self.assertGreater(big, small)
        self.assertGreaterEqual(small, 7)

    def test_tiny_window_does_not_crash(self):
        self.drawn([(1.0, 1.0, 1.5, 1)], size=(60, 60))
        self.assertEqual(self.drawn([(1.0, 1.0, 1.5, 1)], size=(10, 10))[1], [])

    def test_live_update_path_applies_front_filter(self):
        w = self.open("radar")
        w.canvas.w, w.canvas.h = 410, 410
        w.update(frame([]), True)                                   # ilk kare: yon henuz ogrenilmedi
        w.update(frame([(8.0, 0.0), (0.0, 3.0)], x0=2.0), True)     # biri tam onde 8 m, biri yanda 3 m
        r = 410 * 0.46
        per_car = len(art.car_shapes(0, 0, max(16, r / 20 * 4.8), max(7, r / 20 * 2.0), "#fff"))
        polys = [i for i in w.canvas.items if i[0] == "poly" and len(i[1]) > 6]   # 3 koseli on isareti haric
        self.assertEqual(len(polys), 2 * per_car)                   # yalniz yandaki rakip + oyuncu; tam onde olan YOK
        self.assertIn("3.0 m", self.texts(w.canvas.items))

    def test_front_car_within_5m_is_drawn_via_live_path(self):
        w = self.open("radar")
        w.canvas.w, w.canvas.h = 410, 410
        w.update(frame([]), True)
        w.update(frame([(4.0, 0.0)], x0=2.0), True)
        r = 410 * 0.46
        per_car = len(art.car_shapes(0, 0, max(16, r / 20 * 4.8), max(7, r / 20 * 2.0), "#fff"))
        self.assertEqual(len([i for i in w.canvas.items if i[0] == "poly" and len(i[1]) > 6]), 2 * per_car)
        self.assertIn("4.0 m", self.texts(w.canvas.items))
        self.assertIn("ÖN", self.texts(w.canvas.items))


if __name__ == "__main__":
    unittest.main()
