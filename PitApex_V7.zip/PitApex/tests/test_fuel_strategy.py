"""Yakit takibi, pit stratejisi planlayicisi, telemetri baglantisi ve overlay."""
import math
import random
import unittest
from types import SimpleNamespace
from unittest import mock

from core.fuel_tracker import FuelTracker
from core.models import TelemetryFrame
from core.pit_strategy import plan_strategy
from core import strategy_runtime as sr
from telemetry.ac_family import ACCAdapter
from telemetry.lmu import LMUAdapter, RF2ScoringInfo
from tests import rich_fake_tk as rtk
from tests.test_adapters import acc_bufs, lmu_mems
from tests.test_overlay import FakeApp
from ui import overlays_page as op


def fr(lap, fuel, pit=False, last_ms=None, valid=None, **kw):
    return SimpleNamespace(live=True, lap_count=lap, fuel_l=fuel, in_pit=pit, lap_last_ms=last_ms, lap_valid=valid, **kw)


class TrackerTests(unittest.TestCase):
    def drive(self, tr, rows):
        for r in rows:
            tr.update(r)

    def test_clean_laps_average_and_lap_time(self):
        t = FuelTracker()
        self.drive(t, [fr(0, 50), fr(1, 47, last_ms=140000), fr(2, 44.2, last_ms=141000), fr(3, 41.5, last_ms=139000)])
        self.assertEqual(t.count(), 2)            # ilk tur (baslangic baglami belirsiz) sayilmaz
        self.assertAlmostEqual(t.rate(), (2.8 + 2.7) / 2)
        self.assertAlmostEqual(t.lap_time_s(), 140.0)

    def test_pit_lap_and_out_lap_excluded(self):
        t = FuelTracker()
        self.drive(t, [fr(0, 50), fr(1, 47), fr(2, 44),
                       fr(2, 43.9, pit=True),                 # pite girdi
                       fr(2, 80, pit=True),                   # ikmal
                       fr(3, 77.5, pit=True),                 # pitte tur sayaci atladi: sayilmaz
                       fr(4, 74.5)])                          # cikis turu: kirli
        self.assertEqual(t.count(), 1)                        # yalniz pit oncesi temiz tur (47 -> 44)
        self.drive(t, [fr(5, 71.6)])
        self.assertEqual(t.count(), 2)
        self.assertAlmostEqual(t.rate(), (3.0 + 2.9) / 2)

    def test_refuel_without_pit_flag_invalidates_lap(self):
        t = FuelTracker()
        self.drive(t, [fr(0, 50), fr(1, 47), fr(1, 90), fr(2, 87)])
        self.assertEqual(t.count(), 0)

    def test_lap_time_ignored_when_invalid(self):
        t = FuelTracker()
        self.drive(t, [fr(0, 50), fr(1, 47, last_ms=140000), fr(2, 44, last_ms=130000, valid=False), fr(3, 41, last_ms=142000)])
        self.assertEqual(t.count(), 2)
        self.assertIsNone(t.lap_time_s(minimum=3))

    def test_session_restart_resets(self):
        t = FuelTracker()
        self.drive(t, [fr(0, 50), fr(1, 47), fr(2, 44)])
        self.drive(t, [fr(0, 60)])
        self.assertEqual(t.count(), 0)

    def test_missing_data_gives_nothing(self):
        t = FuelTracker()
        self.drive(t, [fr(None, 50), fr(1, None), SimpleNamespace(live=False, lap_count=1, fuel_l=1)])
        self.assertEqual(t.count(), 0)
        self.assertIsNone(t.rate())

    def test_bases(self):
        t = FuelTracker()
        fuel = 100.0
        rows = [fr(0, fuel)]
        for i, used in enumerate((2.0, 2.0, 2.0, 2.0, 2.0, 2.0, 3.0), start=1):
            fuel -= used
            rows.append(fr(i, fuel))
        self.drive(t, rows)
        self.assertAlmostEqual(t.rate('max'), 3.0)
        self.assertAlmostEqual(t.rate('avg'), (5 * 2 + 3) / 6)     # ilk tur (baslangic belirsiz) sayilmaz
        self.assertAlmostEqual(t.rate('avg5'), (2 * 4 + 3) / 5)


class PlanTests(unittest.TestCase):
    def test_no_stop_needed(self):
        p = plan_strategy(fuel=60, rate=2.0, laps_left=20, capacity=100)
        self.assertEqual(p['stops'], 0)
        self.assertEqual(p['stints'], [])
        self.assertAlmostEqual(p['needed'], 42.0)
        self.assertAlmostEqual(p['surplus'], 18.0)

    def test_two_stop_plan_conserves_fuel(self):
        p = plan_strategy(fuel=40, rate=3.0, laps_left=50, capacity=100, reserve_laps=1, current_lap=5)
        self.assertEqual(p['stops'], 2)
        self.assertTrue(p['feasible'])
        self.assertAlmostEqual(40 + sum(s['add_l'] for s in p['stints']), p['needed'])   # sonda tam guvenlik payi kalir
        self.assertEqual(p['stints'][0]['pit_lap'], 5 + p['stints'][0]['pit_after_laps'])
        self.assertEqual(sum(s['next_stint_laps'] for s in p['stints']) + p['stints'][0]['pit_after_laps'], 50)

    def test_mandatory_stop_forces_stop_even_with_enough_fuel(self):
        p = plan_strategy(fuel=90, rate=2.0, laps_left=20, capacity=100, mandatory_stops=1)
        self.assertEqual(p['stops'], 1)
        self.assertEqual(len(p['stints']), 1)

    def test_time_based_laps_use_ceiling(self):
        p = plan_strategy(fuel=60, rate=2.0, time_left_s=25.2 * 100, lap_time_s=100, capacity=100)
        self.assertEqual((p['source'], p['laps_left']), ('time', 26))

    def test_unknown_capacity_does_not_invent_stops(self):
        p = plan_strategy(fuel=10, rate=2.0, laps_left=20)
        self.assertIn('capacity_unknown', p['warnings'])
        self.assertFalse(p['feasible'])
        self.assertEqual(p['stints'], [])

    def test_tank_too_small(self):
        p = plan_strategy(fuel=5, rate=10.0, laps_left=10, capacity=15, reserve_laps=1)
        self.assertIn('capacity_too_small', p['warnings'])

    def test_pit_time_uses_parallel_tyre_change(self):
        p = plan_strategy(fuel=40, rate=3.0, laps_left=50, capacity=100, pit_loss_s=22, fuel_flow_lps=2.5, tyre_time_s=30)
        s = p['stints'][0]
        self.assertAlmostEqual(s['pit_time_s'], 22 + max(s['add_l'] / 2.5, 30))

    def test_fuel_save_hint(self):
        p = plan_strategy(fuel=40, rate=3.0, laps_left=50, capacity=100, pit_loss_s=20)
        fs = p['fuel_save']
        self.assertIsNotNone(fs)
        total = 40 + (p['stops'] - 1) * (100 - p['reserve_l']) - p['reserve_l']
        self.assertAlmostEqual(fs['target_rate'], total / 50)

    def test_invalid_inputs(self):
        for kw in (dict(fuel=None, rate=2, laps_left=5), dict(fuel=10, rate=0, laps_left=5), dict(fuel=10, rate=float('nan'), laps_left=5),
                   dict(fuel=-1, rate=2, laps_left=5), dict(fuel=10, rate=2)):
            self.assertIsNone(plan_strategy(**kw))

    def test_property_plans_are_physically_consistent(self):
        rnd = random.Random(7)
        for _ in range(400):
            cap = rnd.uniform(40, 120)
            rate = rnd.uniform(1.0, 6.0)
            fuel = rnd.uniform(5, cap)
            laps = rnd.randint(1, 120)
            res = rnd.choice([0, 1, 1.5])
            mand = rnd.choice([0, 0, 1, 2])
            p = plan_strategy(fuel=fuel, rate=rate, laps_left=laps, capacity=cap, reserve_laps=res, mandatory_stops=mand)
            self.assertIsNotNone(p)
            if not p['stints']:
                continue
            reserve = res * rate
            arrival = fuel - p['stints'][0]['pit_after_laps'] * rate
            if p['feasible']:
                self.assertGreaterEqual(arrival, min(reserve, fuel) - 1e-6)         # ilk pite rezervle varir (zaten altindaysa hemen pit)
                if arrival < reserve - 1e-6:
                    self.assertIn('below_reserve_now', p['warnings'])
            laps_done = p['stints'][0]['pit_after_laps']
            for s in p['stints']:
                filled = arrival + s['add_l']
                self.assertLessEqual(filled, cap + 1e-6)                            # depoya sigar
                arrival = filled - s['next_stint_laps'] * rate
                laps_done += s['next_stint_laps']
                if p['feasible']:
                    self.assertGreaterEqual(arrival, reserve - 1e-6)                # her stint sonunda rezerv kalir
            self.assertEqual(laps_done, laps)
            self.assertGreaterEqual(p['stops'], mand)


class RuntimeTests(unittest.TestCase):
    def tracker(self):
        t = FuelTracker()
        fuel = 80.0
        t.update(fr(0, fuel))
        for i in range(1, 5):
            fuel -= 2.5
            t.update(fr(i, fuel, last_ms=120000))
        return t

    def frame(self, **kw):
        base = dict(live=True, fuel_l=55.0, fuel_capacity_l=100.0, lap_count=4, session_laps_total=30,
                    session_time_left_s=None)
        base.update(kw)
        return SimpleNamespace(**base)

    def test_auto_fills_from_game_and_measured(self):
        plan, src = sr.build_plan(self.frame(), self.tracker(), {})
        self.assertEqual((src['fuel'], src['rate'], src['capacity'], src['laps']), ('oyun', 'olculen', 'oyun', 'oyun'))
        self.assertEqual(plan['laps_left'], 26)
        self.assertAlmostEqual(plan['rate'], 2.5)

    def test_manual_wins(self):
        plan, src = sr.build_plan(self.frame(), self.tracker(), {'rate': '3,2', 'laps': '10', 'capacity': '90'})
        self.assertEqual((src['rate'], src['laps'], src['capacity']), ('elle', 'elle', 'elle'))
        self.assertAlmostEqual(plan['rate'], 3.2)
        self.assertEqual(plan['laps_left'], 10)

    def test_time_left_with_measured_lap_time(self):
        plan, src = sr.build_plan(self.frame(session_laps_total=None, session_time_left_s=1500.0), self.tracker(), {})
        self.assertEqual(plan['source'], 'time')
        self.assertEqual(plan['laps_left'], math.ceil(1500 / 120.0))

    def test_no_data_gives_none(self):
        plan, src = sr.build_plan(None, None, {})
        self.assertIsNone(plan)
        text, status = sr.overlay_lines(plan, src, None)
        self.assertEqual(status, 'none')

    def test_garbage_inputs_ignored(self):
        plan, src = sr.build_plan(self.frame(), self.tracker(), {'rate': 'abc', 'laps': 'nan', 'pit_loss': '-5'})
        self.assertEqual(src['rate'], 'olculen')
        self.assertIsNotNone(plan)
        self.assertEqual(sr.normalize_inputs({'basis': 'zzz', 'rate': {'x': 1}})['basis'], 'avg5')

    def test_texts(self):
        plan, src = sr.build_plan(self.frame(fuel_l=20.0), self.tracker(), {'pit_loss': '22'})
        text = sr.plan_text(plan, src, self.tracker())
        self.assertIn('PİT PLANI', text)
        self.assertIn('Tahmindir', text)
        lines, status = sr.overlay_lines(plan, src, self.tracker())
        self.assertIn('PİT', lines)
        self.assertIn(status, ('ok', 'warn', 'bad'))
        en = sr.plan_text(plan, src, self.tracker(), 'en')
        self.assertIn('PIT PLAN', en)

    def test_no_stop_overlay_is_green(self):
        plan, src = sr.build_plan(self.frame(fuel_l=95.0, session_laps_total=20), self.tracker(), {})
        lines, status = sr.overlay_lines(plan, src, self.tracker())
        self.assertEqual(status, 'ok')
        self.assertIn('Pit gerekmez', lines)


class AdapterTests(unittest.TestCase):
    def test_acc_capacity_time_and_laps(self):
        f = ACCAdapter().parse(*acc_bufs(s__maxFuel=110.0, g__sessionTimeLeft=1500000.0, g__numberOfLaps=0))
        self.assertAlmostEqual(f.fuel_capacity_l, 110.0)
        self.assertAlmostEqual(f.session_time_left_s, 1500.0)           # ACC milisaniye verir
        self.assertIsNone(f.session_laps_total)
        f2 = ACCAdapter().parse(*acc_bufs(g__numberOfLaps=25))
        self.assertEqual(f2.session_laps_total, 25)

    def test_acc_bad_values_are_none(self):
        f = ACCAdapter().parse(*acc_bufs(s__maxFuel=0.0, g__sessionTimeLeft=float('nan')))
        self.assertIsNone(f.fuel_capacity_l)
        self.assertIsNone(f.session_time_left_s)

    def test_lmu_capacity_and_session_end(self):
        def veh(v):
            v.mFuelCapacity = 90.0
        tel, scm = lmu_mems(vehicle_edit=veh)
        raw = bytearray(scm.data)
        info = RF2ScoringInfo.from_buffer_copy(raw, 12)
        info.mCurrentET, info.mEndET, info.mMaxLaps = 600.0, 2400.0, 2147483647
        raw[12:12 + 548] = bytes(info)
        scm.data = bytes(raw)
        f = LMUAdapter(tel, scm).read()
        self.assertAlmostEqual(f.fuel_capacity_l, 90.0)
        self.assertAlmostEqual(f.session_time_left_s, 1800.0)
        self.assertIsNone(f.session_laps_total)                         # "sinirsiz" degeri tur sayilmaz


class OverlayTests(unittest.TestCase):
    def setUp(self):
        self._p1 = mock.patch.object(op, 'tk', rtk)
        self._p2 = mock.patch.object(op.sys, 'platform', 'win32')
        self._p1.start()
        self._p2.start()
        self.app = FakeApp()
        self.app.language = 'tr'
        self.app.race_analysis = SimpleNamespace(fuel=FuelTracker())
        self.mgr = op.OverlayManager(self.app)

    def tearDown(self):
        self._p2.stop()
        self._p1.stop()

    def test_fuel_overlay_shows_plan_and_color(self):
        self.mgr.open('fuel')
        win = self.mgr.windows['fuel']
        fuel = 70.0
        self.app.race_analysis.fuel.update(fr(0, fuel))
        for i in range(1, 5):
            fuel -= 3.0
            self.app.race_analysis.fuel.update(fr(i, fuel, last_ms=100000))
        f = TelemetryFrame(game='acc', live=True, fuel_l=fuel, fuel_capacity_l=100.0, lap_count=4, session_laps_total=40)
        win.update(f, True)
        text = win.label.cfg['text']
        self.assertIn('YAKIT', text)
        self.assertIn('PİT', text)
        self.assertIn(win.label.cfg['fg'], ('#39d879', '#ffd166', '#fa4848'))

    def test_inputs_persist_through_manager(self):
        self.mgr.set_strategy_inputs({'pit_loss': '21', 'basis': 'max', 'junk': 'x'})
        self.assertEqual(self.mgr.strategy_inputs()['pit_loss'], '21')
        self.assertEqual(self.mgr.strategy_inputs()['basis'], 'max')
        self.assertNotIn('junk', self.app.prefs.data['strategy_inputs'])

    def test_waiting_text_without_telemetry(self):
        self.mgr.open('fuel')
        win = self.mgr.windows['fuel']
        win.update(None, False)
        self.assertIn('Telemetri bekleniyor', win.label.cfg['text'])


if __name__ == '__main__':
    unittest.main()
