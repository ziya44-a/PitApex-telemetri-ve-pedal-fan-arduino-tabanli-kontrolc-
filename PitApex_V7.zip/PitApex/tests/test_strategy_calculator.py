import unittest
from core.strategy_calculator import calculate_strategy

class StrategyTests(unittest.TestCase):
    def test_manual(self):
        p = calculate_strategy(32, 2.7, remaining_laps=15, reserve_laps=1)
        self.assertAlmostEqual(p['required'], 43.2)
        self.assertAlmostEqual(p['shortfall'], 11.2)
    def test_time(self):
        p = calculate_strategy(40, 2.8, remaining_minutes=35, lap_seconds=140)
        self.assertEqual(p['remaining_laps'], 15)
    def test_bad_values(self):
        self.assertIsNone(calculate_strategy(-1, 2, remaining_laps=5))
if __name__ == '__main__': unittest.main()
