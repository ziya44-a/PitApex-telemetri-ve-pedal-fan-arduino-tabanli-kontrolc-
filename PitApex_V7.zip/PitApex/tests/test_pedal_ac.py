"""Pedal sistemi - Assetto Corsa (AC) senaryolari. Oyun gerektirmez; Windows'un bellek davranisi sahte nesnelerle taklit edilir."""
import copy
import ctypes
import time
import types
import unittest

import core.engine as E
import telemetry.legacy_sources as LS
from hardware.arduino import ArduinoLink


class _NT:
    """legacy_sources icinde os.name == 'nt' gibi davranan vekil (gercek os'u bozmaz)."""
    name = "nt"

    def __getattr__(self, k):
        import os
        return getattr(os, k)


def ac_page(gas=0.0, brake=1.0, speed=150.0, abs_=0.6, tc=0.0, pid=1, gear=4):
    d = LS.Physics()
    d.packetId, d.gas, d.brake, d.speedKmh, d.abs, d.tc, d.gear = pid, gas, brake, speed, abs_, tc, gear
    for i in range(4):
        d.wheelAngularSpeed[i] = abs(speed) / 3.6 / 0.33
    return bytes(d)[:LS.ACSource.SIZE]          # AC'nin gercek (kisa) fiziksel sayfasi


class FakeMapped(LS.ACCSource):
    """Haritayi sahte bir bellek bloguyla besler; harita boyutu (region) istenen degerde."""
    def __init__(self, data, region):
        super().__init__()
        self.buf = ctypes.create_string_buffer(data, len(data))
        self.reg = region

    def _open_view(self):
        self.status = "sahte"
        return 1, ctypes.addressof(self.buf), self.reg


class MapRobustness(unittest.TestCase):
    def setUp(self):
        self.orig = LS.os
        LS.os = _NT()

    def tearDown(self):
        LS.os = self.orig

    def test_short_mapping_is_zero_padded_not_a_failure(self):
        page = ac_page()
        src = FakeMapped(page, region=len(page))            # AC: ACC yapisindan KISA harita
        self.assertLess(len(page), LS.ACCSource.SIZE)
        t = src.read()
        self.assertIsNotNone(t, "kisa harita 'veri yok' sayilmamali")
        self.assertTrue(t["valid"])
        self.assertAlmostEqual(t["brake"], 1.0)
        self.assertAlmostEqual(t["abs"], 0.6, places=5)
        self.assertEqual(t["slipRatio"], [0.0, 0.0, 0.0, 0.0], "olmayan alanlar 0 olur, uydurma deger olmaz")

    def test_never_reads_past_region(self):
        big = ac_page() + b"\xff" * 4000                   # haritanin otesinde 'cop' var
        src = FakeMapped(big, region=len(ac_page()))
        raw = src.raw()
        self.assertEqual(len(raw), LS.ACCSource.SIZE)
        self.assertEqual(raw[len(ac_page()):], b"\0" * (LS.ACCSource.SIZE - len(ac_page())),
                         "region disindaki baytlar okunmamali")

    def test_wide_mapping_works(self):
        src = FakeMapped(ac_page() + b"\0" * 3000, region=4096)
        self.assertTrue(src.read()["valid"])

    def test_reverse_speed_is_valid_and_positive(self):
        t = FakeMapped(ac_page(speed=-12.0, brake=0.0), region=600).read()
        self.assertTrue(t["valid"])
        self.assertAlmostEqual(t["speed"], 12.0, places=3)


class FamilyFix(unittest.TestCase):
    def make(self, procs, src="ACC", auto=False):
        e = E.Engine(copy.deepcopy(E.DEFAULTS), ArduinoLink())
        e.src = LS.SOURCES[src]()
        e.auto = auto
        e.procs = set(procs)
        return e

    def test_acs_running_but_acc_selected_switches_to_ac(self):
        e = self.make({"acs.exe"}, "ACC")
        e._family_check(False)
        self.assertEqual(e.pending_source, "AC")

    def test_acc_running_but_ac_selected_switches_to_acc(self):
        e = self.make({"ac2-win64-shipping.exe"}, "AC")
        e._family_check(False)
        self.assertEqual(e.pending_source, "ACC")

    def test_correct_class_is_left_alone(self):
        for procs, src in (({"acs.exe"}, "AC"), ({"ac2-win64-shipping.exe"}, "ACC"), (set(), "ACC"),
                           ({"acs.exe", "ac2-win64-shipping.exe"}, "AC")):
            e = self.make(procs, src)
            e._family_check(True)
            self.assertIsNone(e.pending_source, (procs, src))

    def test_manual_source_mismatch_gives_clear_hint(self):
        e = self.make({"le mans ultimate.exe"}, "ACC", auto=False)
        e._family_check(False)
        self.assertIn("LMU", e.hint)
        self.assertIn("Otomatik", e.hint)
        e.auto = True
        e._family_check(False)
        self.assertEqual(e.hint, "", "otomatik modda uyari gerekmez")

    def test_hint_cleared_when_live(self):
        e = self.make({"le mans ultimate.exe"}, "ACC", auto=False)
        e._family_check(True)
        self.assertEqual(e.hint, "")


class EngineEndToEndAC(unittest.TestCase):
    """Gercek Engine ipligi: AC verisi -> Arduino komutlari."""

    class Ser:
        def __init__(self):
            self.w = []

        def write(self, b):
            self.w.append(b.decode())

        def readline(self):
            time.sleep(0.01)
            return b""

        def close(self):
            pass

    def run_engine(self, strict, manual_source=None, seconds=3.2):
        state = {"pid": 1}
        mapsize = len(ac_page())

        def fake_raw(self):
            if strict and self.SIZE > mapsize and not getattr(self, "_padded", False):
                pass
            p = ac_page(pid=state["pid"])
            return (p + b"\0" * (self.SIZE - len(p))) if self.SIZE >= len(p) else p[:self.SIZE]
        saved = (LS.MapSource.raw, LS.MapSource._ensure, E.probe_games, E.running_processes)
        LS.MapSource.raw, LS.MapSource._ensure = fake_raw, (lambda self: 1)
        E.probe_games = lambda: "AC"
        E.running_processes = lambda: {"acs.exe"}
        try:
            ser = self.Ser()
            link = ArduinoLink()
            link.ser, link.ready_at, link.fw_version = ser, 0, 3
            eng = E.Engine(copy.deepcopy(E.DEFAULTS), link)
            if manual_source:
                eng.auto = False
                eng.src = LS.SOURCES[manual_source]()
            eng.start()
            t0 = time.time()
            while time.time() - t0 < seconds:
                state["pid"] += 1
                time.sleep(0.003)
            eng.running = False
            time.sleep(0.05)
            return eng, [w for w in ser.w if w.startswith("M1,") and not w.startswith("M1,0,")]
        finally:
            LS.MapSource.raw, LS.MapSource._ensure, E.probe_games, E.running_processes = saved

    def test_auto_detect_vibrates_brake_motor_in_ac(self):
        eng, cmds = self.run_engine(True)
        self.assertEqual(eng.src.NAME, "AC")
        self.assertGreater(len(cmds), 20, "ABS aktifken fren motoruna titresim komutu gitmeli")

    def test_manual_acc_in_ac_is_corrected_and_works(self):
        eng, cmds = self.run_engine(True, manual_source="ACC")
        self.assertEqual(eng.src.NAME, "AC", "ACC secili olsa da AC calisiyorsa dogru siniflandirma kullanilmali")
        self.assertGreater(len(cmds), 20)


if __name__ == "__main__":
    unittest.main()
