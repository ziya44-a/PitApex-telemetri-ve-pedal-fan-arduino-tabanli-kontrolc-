import unittest
from core.strategy_calculator import calculate_strategy
from ui.i18n import translate

class V7RegressionTests(unittest.TestCase):
    def test_strategy_manual(self):
        p=calculate_strategy(32,2.7,remaining_laps=15,reserve_laps=1)
        self.assertAlmostEqual(p['shortfall'],11.2)
    def test_strategy_time(self):
        self.assertEqual(calculate_strategy(40,2.8,remaining_minutes=35,lap_seconds=140)['remaining_laps'],15)
    def test_strategy_invalid(self):
        for bad in (float('nan'),float('inf'),-1):
            self.assertIsNone(calculate_strategy(bad,2.8,remaining_laps=10))
    def test_english_titles(self):
        for value in ('Lastik performans analizi','Yakıt ve pit stop stratejisi','A · Oturum ve tur istatistikleri','Mevcut yakıt (L)'):
            self.assertNotEqual(translate(value,'en'),value)
