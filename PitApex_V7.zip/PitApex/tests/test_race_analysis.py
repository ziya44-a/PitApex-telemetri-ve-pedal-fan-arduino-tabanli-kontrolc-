import unittest
from types import SimpleNamespace
from core.race_analysis import RaceAnalysis

class TestRaceAnalysis(unittest.TestCase):
    def test_consumption_and_refuel(self):
        a = RaceAnalysis()
        def frame(lap, fuel, t):
            return SimpleNamespace(game='ACC', track_id='spa', car_id='296', live=True,
                                   lap_count=lap, fuel_l=fuel, in_pit=False,
                                   t=t, tyre_temp_c=[80,81,82,83])
        a.update(frame(0, 30, 0))
        a.update(frame(1, 27, 140))
        a.update(frame(2, 24, 280))
        self.assertEqual(a.fuel_per_lap, 3)
        self.assertAlmostEqual(a.fuel_plan(10)['shortfall'], 9)
        a.update(frame(2, 40, 290))
        self.assertIsNone(a.fuel_per_lap)
        a.update(frame(3, 37, 430))
        self.assertIsNone(a.fuel_per_lap)
        a.update(frame(4, 34, 570))
        self.assertEqual(a.fuel_per_lap, 3)

if __name__ == '__main__':
    unittest.main()
