"""Gelistirici araci: radar cizimini (kaydedilen tuval ogeleri) PIL ile PNG onizlemeye cevirir.
Gercek Tk goruntusu DEGILDIR (yazi tipi farkli); ayni cizim kodunun yerlesimini ve renk gecisini gormek icindir.
Kullanim:  python3 tests/render_radar_preview.py cikti.png     (Pillow gerekir)"""
import os, sys, math
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT,'tests','fake_tk'))
from unittest import mock
from PIL import Image, ImageDraw, ImageFont
from tests import rich_fake_tk as rtk
from tests.test_overlay import FakeApp
from ui import overlays_page as op

FONT=['/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf']
def font(pt):
    for p in FONT:
        if os.path.exists(p): return ImageFont.truetype(p, max(7,int(round(pt*96/72))))
    return ImageFont.load_default()
def rgb(c):
    c=c.lstrip('#'); return tuple(int(c[i:i+2],16) for i in (0,2,4))

def raster(canvas, scale=2):
    W,H=canvas.w*scale, canvas.h*scale
    img=Image.new('RGBA',(W,H),(0,0,0,0)); d=ImageDraw.Draw(img)
    for kind,a,k in canvas.items:
        fill=k.get('fill'); out=k.get('outline')
        if kind=='oval':
            x0,y0,x1,y1=[v*scale for v in a]
            if out: 
                wd=int(k.get('width',1)*scale)
                if k.get('dash'):
                    cx,cy=(x0+x1)/2,(y0+y1)/2; rr=(x1-x0)/2
                    n=180
                    for i in range(0,n,2):
                        a0=2*math.pi*i/n; a1=2*math.pi*(i+1)/n
                        d.line([cx+rr*math.cos(a0),cy+rr*math.sin(a0),cx+rr*math.cos(a1),cy+rr*math.sin(a1)],fill=rgb(out)+(255,),width=wd)
                else: d.ellipse([x0,y0,x1,y1],outline=rgb(out)+(255,),width=wd)
            if fill: d.ellipse([x0,y0,x1,y1],fill=rgb(fill)+(255,))
        elif kind=='line':
            pts=[v*scale for v in a]; d.line(pts,fill=rgb(k['fill'])+(255,),width=int(k.get('width',1)*scale),joint='curve')
            if k.get('capstyle')=='round':
                r=k.get('width',1)*scale/2
                for (x,y) in ((pts[0],pts[1]),(pts[-2],pts[-1])): d.ellipse([x-r,y-r,x+r,y+r],fill=rgb(k['fill'])+(255,))
        elif kind=='poly':
            pts=[v*scale for v in a]
            d.polygon(pts,fill=rgb(fill)+(255,) if fill else None, outline=rgb(out)+(255,) if out else None)
        elif kind=='text':
            fam,pt,*_=k['font']; f=font(pt*scale*0.96)
            anchor={'w':'lm','e':'rm','center':'mm','sw':'ls','se':'rs','nw':'la'}.get(k.get('anchor','center'),'mm')
            d.text((a[0]*scale,a[1]*scale),k['text'],fill=rgb(k['fill'])+(255,),font=f,anchor=anchor)
    return img

def render(targets, size=(410,410), bg=(70,98,72)):
    with mock.patch.object(op,'tk',rtk), mock.patch.object(op.sys,'platform','win32'):
        app=FakeApp(); mgr=op.OverlayManager(app); mgr.open('radar'); w=mgr.windows['radar']
        w.canvas.w,w.canvas.h=size; w._draw_radar(targets)
        fg=raster(w.canvas)
    # oyun gorunumu taklidi arka plan
    base=Image.new('RGBA',fg.size,bg+(255,)); d=ImageDraw.Draw(base)
    for x in range(0,fg.size[0],80): d.line([x,0,x-60,fg.size[1]],fill=(90,118,92,255),width=18)
    base.alpha_composite(fg)
    return base.convert('RGB')

def t(lat,fwd): 
    d=math.hypot(lat,fwd); s=int(math.floor((math.atan2(lat,fwd)+math.pi/8)/(math.pi/4)))%8
    return (lat,fwd,d,s)


sc = [t(-2.2, -3.5), t(3.0, -8.0), t(-6.5, 2.0), t(0.5, -14.0), t(5.5, 12.0)]
imgs = [render(sc, (410, 410)), render([t(0.6, 3.8), t(-4, -2)], (260, 260)), render([t(7, -4)], (420, 300)),
        render(None, (410, 410))]
W = max(i.size[0] for i in imgs)
H = max(i.size[1] for i in imgs)
sheet = Image.new('RGB', (W * 2 + 12, H * 2 + 12), (255, 255, 255))
for n, im in enumerate(imgs):
    sheet.paste(im, ((n % 2) * (W + 12), (n // 2) * (H + 12)))
out = sys.argv[1] if len(sys.argv) > 1 else 'radar_preview.png'
sheet.save(out)
print('yazildi:', out, sheet.size)
