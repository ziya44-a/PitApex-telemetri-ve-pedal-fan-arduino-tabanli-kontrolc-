"""Tur basina yakit tuketimi ve tur suresi. Yalnizca TEMIZ turlar sayilir:
pite giren/pitten cikan tur, yakit ikmali yapilan tur ve sayac sicramasi olan tur hesaba katilmaz.
Oyun yakit ya da tur sayaci vermiyorsa hicbir sey uretilmez (tahmin yok)."""
import math
from collections import deque
from statistics import mean, pstdev

BASES = ('avg5', 'avg', 'max')
BASIS_LABELS = {'avg5': 'Son 5 tur ort.', 'avg': 'Tüm turlar ort.', 'max': 'En yüksek (güvenli)'}


def _num(v, lo, hi):
    try:
        x = float(v)
    except (TypeError, ValueError):
        return None
    return x if math.isfinite(x) and lo <= x <= hi else None


class FuelTracker:
    def __init__(self, keep=20):
        self.laps = deque(maxlen=keep)       # {'lap','fuel','time_s'}
        self.lap = None                      # tamamlanan tur sayaci (oyunun)
        self.start_fuel = None
        self.last_fuel = None
        self.dirty = True                    # mevcut tur temiz mi? (bilinmiyorsa kirli)

    def reset(self):
        self.__init__(self.laps.maxlen)

    def update(self, frame):
        if frame is None or not getattr(frame, 'live', False):
            return
        lap = getattr(frame, 'lap_count', None)
        fuel = _num(getattr(frame, 'fuel_l', None), 0, 1000)
        if lap is None or fuel is None:
            return
        in_pit = getattr(frame, 'in_pit', None) is True
        if self.lap is not None and lap < self.lap:          # yeni oturum / geri sarma
            self.reset()
        if self.lap is None:
            self.lap, self.start_fuel, self.last_fuel, self.dirty = lap, fuel, fuel, True
            return
        if lap == self.lap:
            if fuel > self.last_fuel + 0.3:                  # ikmal: bu turun tuketimi anlamsiz
                self.dirty, self.start_fuel = True, fuel
            if in_pit:
                self.dirty = True
        elif lap == self.lap + 1:
            used = self.start_fuel - fuel if self.start_fuel is not None else None
            if not self.dirty and not in_pit and used is not None and 0.02 < used < 50:
                t = None
                ms = _num(getattr(frame, 'lap_last_ms', None), 5000, 3600000)
                if ms is not None and getattr(frame, 'lap_valid', None) is not False:
                    t = ms / 1000.0
                self.laps.append({'lap': lap, 'fuel': used, 'time_s': t})
            self.lap, self.start_fuel = lap, fuel
            self.dirty = in_pit                              # pitte basladiysa cikis turu temiz degil
        else:                                                # sayac sicradi
            self.lap, self.start_fuel, self.dirty = lap, fuel, True
        self.last_fuel = fuel

    # ---- istatistikler ----
    def count(self):
        return len(self.laps)

    def rate(self, basis='avg5', minimum=2):
        """L/tur. Yeterli temiz tur yoksa None."""
        vals = [r['fuel'] for r in self.laps]
        if len(vals) < minimum:
            return None
        if basis == 'max':
            return max(vals)
        if basis == 'avg':
            return mean(vals)
        return mean(vals[-5:])

    def spread(self):
        vals = [r['fuel'] for r in self.laps]
        if len(vals) < 2:
            return None
        return {'min': min(vals), 'max': max(vals), 'stdev': pstdev(vals), 'last': vals[-1]}

    def lap_time_s(self, minimum=2):
        """Temiz turlarin ortalama tur suresi (son 5)."""
        vals = [r['time_s'] for r in self.laps if r['time_s'] is not None]
        return mean(vals[-5:]) if len(vals) >= minimum else None
