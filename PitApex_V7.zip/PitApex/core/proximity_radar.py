"""World-coordinate proximity radar; heading derived from player displacement.
No guessed car positions or orientation. Units are metres.
"""
import math
import time

RANGE_M = 20.0             # radarin gosterdigi en uzak mesafe
WARN_YELLOW_M = 10.0       # bu mesafede SARI uyari baslar
WARN_RED_M = 5.0           # bu mesafede ve icinde tam KIRMIZI
# "Tam onumuzdeki" arac: onde ve yanal farki seridimiz kadar (+-2.5 m). Ekranda zaten gorundugu icin
# yalnizca FRONT_REVEAL_M icine girince (carpisma yakin) radarda gosterilir.
FRONT_LANE_HALF_WIDTH_M = 2.5
FRONT_REVEAL_M = 5.0


def threat_ratio(distance):
    """Tehdit orani: 10 m ve otesi -> None (uyari yok); 10 m -> 0.0 (sari); 5 m ve icinde -> 1.0 (kirmizi); arasi dogrusal."""
    if distance is None or distance > WARN_YELLOW_M:
        return None
    if distance <= WARN_RED_M:
        return 1.0
    return (WARN_YELLOW_M - distance) / (WARN_YELLOW_M - WARN_RED_M)


def is_directly_ahead(lateral, longitudinal):
    """Tam onumuzde mi: ileride ve kendi seridimizin genisliginde."""
    return longitudinal > 0 and abs(lateral) <= FRONT_LANE_HALF_WIDTH_M


class RadarTracker:
    def __init__(self):
        self.last = None
        self.heading = None
        self.last_heading_at = 0.0
        self.context = None

    def reset(self):
        self.last = None
        self.heading = None
        self.last_heading_at = 0.0

    def calculate(self, frame, now=None):
        now = time.monotonic() if now is None else now
        if frame is None or not getattr(frame, 'live', False):
            self.reset()
            return None
        context = (getattr(frame, 'game', None), getattr(frame, 'track_id', None))
        if context != self.context:
            self.reset()
            self.context = context
        cars = getattr(frame, 'cars', None)
        if not cars or sum(bool(c.get('me')) for c in cars) != 1:
            self.reset()
            return None
        me = next(c for c in cars if c.get('me'))
        try:
            x, z = float(me['x']), float(me['z'])
            if not (math.isfinite(x) and math.isfinite(z)):
                raise ValueError('invalid position')
        except (ValueError, TypeError, KeyError):
            self.reset()
            return None
        if self.last is not None:
            px, pz, pt = self.last
            displacement = math.hypot(x-px, z-pz)
            dt = now-pt
            if displacement > 150 or dt > 2 or dt < 0:
                self.heading = None
            elif dt > 0 and displacement >= 0.35 and getattr(frame, 'speed_kmh', 0) and frame.speed_kmh >= 8:
                self.heading = math.atan2(z-pz, x-px)
                self.last_heading_at = now
        self.last = (x, z, now)
        if self.heading is None or now-self.last_heading_at > 3:
            return None
        forward = (math.cos(self.heading), math.sin(self.heading))
        right = (-forward[1], forward[0])  # Correct screen-side mapping for game X/Z coordinates
        output = []
        for c in cars:
            if c.get('me') or c.get('pit'):
                continue
            try:
                dx, dz = float(c['x'])-x, float(c['z'])-z
                d = math.hypot(dx, dz)
            except (ValueError, TypeError, KeyError):
                continue
            if not math.isfinite(d) or d > RANGE_M or d < 0.01:
                continue
            lateral = dx*right[0]+dz*right[1]
            longitudinal = dx*forward[0]+dz*forward[1]
            if is_directly_ahead(lateral, longitudinal) and d > FRONT_REVEAL_M:
                continue          # tam onumuzdeki arac: 5 m icine girmedikce gosterilmez
            # 0 = front, clockwise thereafter
            sector = int(math.floor((math.atan2(lateral, longitudinal)+math.pi/8)/(math.pi/4))) % 8
            output.append((lateral, longitudinal, d, sector))
        return output
