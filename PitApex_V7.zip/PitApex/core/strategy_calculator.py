"""Offline, pure calculations for PitApex fuel planning. No network access."""
import math

def calculate_strategy(fuel, rate, remaining_laps=None, remaining_minutes=None,
                       lap_seconds=None, reserve_laps=1, tank_capacity=None,
                       pit_loss_seconds=None, mandatory_stops=0):
    def valid(value, minimum=0, maximum=1e7):
        if value is None: return None
        try: x = float(value)
        except (ValueError, TypeError): return None
        return x if math.isfinite(x) and minimum <= x <= maximum else None
    fuel = valid(fuel, 0, 1000)
    rate = valid(rate, .001, 100)
    remaining_laps = valid(remaining_laps, 0, 10000)
    remaining_minutes = valid(remaining_minutes, 0, 10080)
    lap_seconds = valid(lap_seconds, 1, 3600)
    reserve_laps = valid(reserve_laps, 0, 100)
    tank_capacity = valid(tank_capacity, 0, 1000)
    pit_loss_seconds = valid(pit_loss_seconds, 0, 3600)
    mandatory_stops = valid(mandatory_stops, 0, 100)
    source = 'laps'
    if remaining_laps is None and remaining_minutes is not None and lap_seconds is not None:
        remaining_laps = math.ceil(remaining_minutes * 60 / lap_seconds)
        source = 'time_estimate'
    if fuel is None or rate is None or remaining_laps is None or reserve_laps is None:
        return None
    required = (remaining_laps + reserve_laps) * rate
    shortfall = max(0, required - fuel)
    # Fuel that can be added in one stop, assuming current fuel at time of refuelling.
    capacity_warning = tank_capacity is not None and required > tank_capacity
    return dict(source=source, remaining_laps=remaining_laps, fuel=fuel, rate=rate,
                range_laps=fuel / rate, required=required, shortfall=shortfall,
                surplus=max(0, fuel-required), capacity_warning=capacity_warning,
                tank_capacity=tank_capacity, pit_loss_seconds=pit_loss_seconds,
                mandatory_stops=int(mandatory_stops or 0))
