"""Conservative live tyre trends and fuel strategy; missing telemetry stays missing."""
from collections import deque
from statistics import mean

from core.fuel_tracker import FuelTracker

class RaceAnalysis:
    def __init__(self):
        self.key = None
        self.last_lap = None
        self.last_fuel = None
        self.consumptions = deque(maxlen=8)
        self.tyres = [deque(maxlen=90) for _ in range(4)]
        self.last_sample = None
        self.latest = None
        self.fuel = FuelTracker()

    def update(self, frame):
        if frame is None or not frame.live:
            return
        key = (frame.game, frame.track_id, frame.car_id)
        if key != self.key or (self.last_lap is not None and frame.lap_count is not None and frame.lap_count < self.last_lap):
            self.__init__()
            self.key = key
        self.latest = frame
        self.fuel.update(frame)
        lap = frame.lap_count
        fuel = frame.fuel_l
        if lap is not None and fuel is not None:
            if self.last_lap is None:
                self.last_lap, self.last_fuel = lap, fuel
            elif lap == self.last_lap:
                # Refuelling must invalidate the current lap's consumption baseline.
                if self.last_fuel is not None and fuel > self.last_fuel + 0.5:
                    self.last_fuel = fuel
                    self.last_lap = lap
                    self.consumptions.clear()
            elif lap == self.last_lap + 1:
                delta = self.last_fuel - fuel if self.last_fuel is not None else None
                if delta is not None and 0.05 < delta < 30 and frame.in_pit is not True:
                    self.consumptions.append(delta)
                self.last_lap, self.last_fuel = lap, fuel
            else:
                self.last_lap, self.last_fuel = lap, fuel
        if self.last_sample is None or frame.t - self.last_sample >= 1.0:
            self.last_sample = frame.t
            for i, value in enumerate((frame.tyre_temp_c or [None]*4)[:4]):
                if value is not None:
                    self.tyres[i].append(value)

    @property
    def fuel_per_lap(self):
        return mean(self.consumptions) if len(self.consumptions) >= 2 else None

    def fuel_plan(self, remaining_laps, reserve=1):
        rate = self.fuel_per_lap
        fuel = getattr(self.latest, 'fuel_l', None)
        if rate is None or fuel is None or remaining_laps is None or remaining_laps < 0:
            return None
        required = (remaining_laps + reserve) * rate
        return {'rate': rate, 'range': fuel / rate, 'required': required,
                'shortfall': max(0.0, required - fuel), 'fuel': fuel,
                'sample_count': len(self.consumptions)}

    def tyre_trend(self, index):
        history = self.tyres[index]
        if len(history) < 12:
            return None
        return mean(list(history)[-6:]) - mean(list(history)[:6])
