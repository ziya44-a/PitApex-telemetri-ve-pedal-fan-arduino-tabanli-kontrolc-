"""Telemetri + elle girilen degerler -> yakit/pit plani. Elle girilen deger HER ZAMAN onceliklidir;
bos alan otomatik (oyunun gercek verisi ya da olculen temiz tur ortalamasi) ile doldurulur."""
import math

from core.fuel_tracker import BASES
from core.pit_strategy import plan_strategy

FIELDS = ('fuel', 'rate', 'laps', 'minutes', 'lap_seconds', 'reserve', 'capacity', 'pit_loss', 'flow', 'tyre', 'mandatory')
DEFAULT_INPUTS = {'reserve': '1', 'mandatory': '0', 'basis': 'avg5'}


def _num(v):
    if v is None:
        return None
    try:
        x = float(str(v).strip().replace(',', '.'))
    except ValueError:
        return None
    return x if math.isfinite(x) else None


def normalize_inputs(raw):
    out = dict(DEFAULT_INPUTS)
    if isinstance(raw, dict):
        for k in FIELDS:
            if k in raw and isinstance(raw[k], (str, int, float)):
                out[k] = str(raw[k])[:12]
        if raw.get('basis') in BASES:
            out['basis'] = raw['basis']
    return out


def build_plan(frame, tracker, inputs):
    """Dondurur (plan | None, kaynaklar). kaynaklar: alan -> 'elle' | 'oyun' | 'olculen' | None."""
    inp = normalize_inputs(inputs)
    src = {}

    def pick(key, auto, auto_src):
        manual = _num(inp.get(key))
        if manual is not None:
            src[key] = 'elle'
            return manual
        src[key] = auto_src if auto is not None else None
        return auto

    live = frame is not None and getattr(frame, 'live', False)
    g = (lambda n: getattr(frame, n, None)) if live else (lambda n: None)
    lap_time_auto = tracker.lap_time_s() if tracker is not None else None
    rate_auto = tracker.rate(inp['basis']) if tracker is not None else None
    fuel = pick('fuel', g('fuel_l'), 'oyun')
    rate = pick('rate', rate_auto, 'olculen')
    capacity = pick('capacity', g('fuel_capacity_l'), 'oyun')
    lap_time = pick('lap_seconds', lap_time_auto, 'olculen')
    laps_auto = None
    total, done = g('session_laps_total'), g('lap_count')
    if total is not None and done is not None and total >= done:
        laps_auto = total - done
    laps = pick('laps', laps_auto, 'oyun')
    minutes_auto = g('session_time_left_s')
    minutes = pick('minutes', None if minutes_auto is None else minutes_auto / 60.0, 'oyun')
    reserve = _num(inp.get('reserve'))
    plan = plan_strategy(
        fuel, rate, laps_left=laps, time_left_s=None if minutes is None else minutes * 60.0, lap_time_s=lap_time,
        capacity=capacity, reserve_laps=1.0 if reserve is None else reserve,
        mandatory_stops=_num(inp.get('mandatory')) or 0, pit_loss_s=_num(inp.get('pit_loss')),
        fuel_flow_lps=_num(inp.get('flow')), tyre_time_s=_num(inp.get('tyre')), current_lap=g('lap_count'))
    return plan, src


def overlay_lines(plan, src, tracker=None, lang='tr'):
    """Overlay icin kisa metin + durum rengi anahtari ('ok' | 'warn' | 'bad' | 'none')."""
    en = lang == 'en'
    tr = lambda a, b: b if en else a        # noqa: E731
    if plan is None:
        n = tracker.count() if tracker is not None else 0
        return (tr('YAKIT\nVeri bekleniyor (en az 2 temiz tur)', 'FUEL\nWaiting for data (2 clean laps)')
                if n < 2 else tr('YAKIT\nKalan tur/süre girin', 'FUEL\nEnter laps/time left')), 'none'
    lines = ['%s %.1f L   %.2f L/%s' % (tr('YAKIT', 'FUEL'), plan['fuel'], plan['rate'], tr('tur', 'lap')),
             '%s %.1f %s   %s %d' % (tr('Menzil', 'Range'), plan['range_laps'], tr('tur', 'laps'), tr('Kalan', 'Left'), plan['laps_left'])]
    status = 'ok'
    if plan['stops'] == 0 and plan['shortfall'] <= 0:
        lines.append(tr('Pit gerekmez  (+%.1f L fazla)' % plan['surplus'], 'No stop needed (+%.1f L spare)' % plan['surplus']))
    elif plan['stints']:
        s = plan['stints'][0]
        w = plan['first_window']
        win = ('%d–%d' % (w['earliest_lap'], w['latest_lap'])) if w and w['latest_lap'] is not None else \
              ('%d–%d %s' % (w['earliest'], w['latest'], tr('tur sonra', 'laps')))
        lines.append('%s: %d   %s %s' % (tr('PİT', 'PIT'), plan['stops'], tr('Pencere', 'Window'), win))
        lines.append('%s %.0f L' % (tr('Eklenecek', 'Add'), s['add_l']))
        status = 'bad' if not plan['feasible'] else ('warn' if plan['shortfall'] > 0 else 'ok')
    elif 'capacity_unknown' in plan['warnings']:
        lines.append(tr('Yakıt açığı %.1f L (depo kapasitesi bilinmiyor)' % plan['shortfall'],
                        'Short by %.1f L (tank size unknown)' % plan['shortfall']))
        status = 'bad'
    else:
        lines.append(tr('Plan uygulanamaz', 'Plan not feasible'))
        status = 'bad'
    return '\n'.join(lines), status


_SRC_TR = {'elle': 'elle', 'oyun': 'oyun', 'olculen': 'ölçülen', None: '—'}
_SRC_EN = {'elle': 'manual', 'oyun': 'game', 'olculen': 'measured', None: '—'}


def plan_text(plan, src, tracker=None, lang='tr'):
    """Sayfa icin ayrintili metin: degerler + kaynaklari + pit plani."""
    en = lang == 'en'
    tr = lambda a, b: b if en else a        # noqa: E731
    sl = _SRC_EN if en else _SRC_TR
    if plan is None:
        n = tracker.count() if tracker is not None else 0
        return tr('Hesap için yakıt, tüketim ve kalan tur (veya kalan süre + tur süresi) gerekli.\n'
                  'Tüketim otomatik ölçülür: en az 2 TEMİZ tur gerekir (pit/ikmal turları sayılmaz). Temiz tur: %d' % n,
                  'Fuel, consumption and laps (or time + lap time) are needed.\n'
                  'Consumption is measured automatically: at least 2 CLEAN laps needed (pit/refuel laps excluded). Clean laps: %d' % n)
    L = []
    L.append(tr('Mevcut yakıt: ', 'Current fuel: ') + '%.1f L (%s)' % (plan['fuel'], sl[src.get('fuel')]))
    extra = ''
    if tracker is not None and src.get('rate') == 'olculen':
        sp = tracker.spread()
        extra = ' [%d %s%s]' % (tracker.count(), tr('temiz tur', 'clean laps'),
                                ', %.2f–%.2f' % (sp['min'], sp['max']) if sp else '')
    L.append(tr('Tüketim: ', 'Consumption: ') + '%.2f L/%s (%s)%s' % (plan['rate'], tr('tur', 'lap'), sl[src.get('rate')], extra))
    L.append(tr('Depo kapasitesi: ', 'Tank capacity: ') + ('%.0f L (%s)' % (plan['capacity'], sl[src.get('capacity')])
                                                        if plan['capacity'] else tr('bilinmiyor', 'unknown')))
    L.append(tr('Kalan tur: ', 'Laps left: ') + '%d%s' % (plan['laps_left'], tr(' (süreden tahmin)', ' (estimated from time)') if plan['source'] == 'time' else ''))
    L.append(tr('Yakıt menzili: ', 'Fuel range: ') + '%.1f %s' % (plan['range_laps'], tr('tur', 'laps')))
    L.append(tr('Gerekli yakıt (güvenlik dahil): ', 'Fuel required (incl. reserve): ') + '%.1f L' % plan['needed'] +
             ('   ' + tr('Açık: ', 'Short: ') + '%.1f L' % plan['shortfall'] if plan['shortfall'] > 0
              else '   ' + tr('Fazla: ', 'Spare: ') + '%.1f L' % plan['surplus']))
    L.append('')
    if plan['stops'] == 0 and plan['shortfall'] <= 0:
        L.append(tr('PİT PLANI: pit gerekmez (zorunlu pit yoksa).', 'PIT PLAN: no stop needed (if none is mandatory).'))
    elif plan['stints']:
        L.append(tr('PİT PLANI: %d stop' % plan['stops'], 'PIT PLAN: %d stop(s)' % plan['stops']) +
                 ('' if plan['feasible'] else tr('  ⚠ plan yetmiyor', '  ⚠ plan falls short')))
        for s in plan['stints']:
            when = (tr('tur %d sonunda' % s['pit_lap'], 'end of lap %d' % s['pit_lap']) if s['pit_lap'] is not None
                    else tr('%d tur sonra' % s['pit_after_laps'], 'after %d laps' % s['pit_after_laps']))
            t = ('  |  ~%.0f %s' % (s['pit_time_s'], tr('sn', 's'))) if s['pit_time_s'] is not None else ''
            L.append('  %s %d: %s  |  +%.0f L  |  %s %d %s%s' % (tr('Stop', 'Stop'), s['stop'], when, s['add_l'],
                                                                 tr('sonraki stint', 'next stint'), s['next_stint_laps'], tr('tur', 'laps'), t))
        w = plan['first_window']
        if w:
            L.append(tr('  1. stop penceresi: ', '  Stop 1 window: ') + (
                tr('tur %d – %d' % (w['earliest_lap'], w['latest_lap']), 'lap %d – %d' % (w['earliest_lap'], w['latest_lap']))
                if w['latest_lap'] is not None else tr('%d – %d tur sonra' % (w['earliest'], w['latest']), '%d – %d laps from now' % (w['earliest'], w['latest']))))
        if plan['pit_time_total_s']:
            L.append(tr('  Toplam pit süresi (tahmini): ', '  Total pit time (est.): ') + '%.0f %s' % (plan['pit_time_total_s'], tr('sn', 's')))
        fs = plan['fuel_save']
        if fs and fs['save_pct'] > 0 and fs['feasible']:
            L.append(tr('Bir stop eksik için: tüketimi %%%.0f azalt (hedef %.2f L/tur)' % (fs['save_pct'], fs['target_rate']),
                        'To skip one stop: save %.0f%% fuel (target %.2f L/lap)' % (fs['save_pct'], fs['target_rate'])) +
                 (tr('; kazanç ~%.0f sn' % fs['time_gain_s'], '; gain ~%.0f s' % fs['time_gain_s']) if fs['time_gain_s'] else ''))
    for w in plan['warnings']:
        L.append({'capacity_unknown': tr('⚠ Depo kapasitesi bilinmiyor: durak sayısı hesaplanamaz (kapasiteyi elle gir).', '⚠ Tank size unknown: stops cannot be planned (enter capacity).'),
                  'capacity_too_small': tr('⚠ Depo, güvenlik payıyla bile bir tur yetmiyor.', '⚠ Tank cannot hold even one lap plus reserve.'),
                  'below_reserve_now': tr('⚠ Yakıt güvenlik payının altında: hemen pit.', '⚠ Fuel is below the reserve: pit now.'),
                  'not_enough_with_planned_stops': tr('⚠ Planlanan duraklarla yakıt yetmiyor.', '⚠ Planned stops do not provide enough fuel.')}.get(w, w))
    L.append(tr('Tahmindir: sabit tüketim, tek sürücü varsayılır; trafik, sarı bayrak, yağmur ve rakipler hesaba katılmaz.',
                'Estimate only: constant consumption, single driver; traffic, yellow flags, rain and rivals are not considered.'))
    return '\n'.join(L)
