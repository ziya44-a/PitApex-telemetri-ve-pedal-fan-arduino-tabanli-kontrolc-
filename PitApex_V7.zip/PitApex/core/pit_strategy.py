"""Yakit ve pit stop stratejisi (saf hesap, cevrimdisi). Sabit tuketim ve tek surucu varsayar.

Kurallar: her stint sonunda en az `reserve` kadar yakit kalir; pitte depo kapasiteye kadar doldurulur;
duraklar mumkun oldugunca esit stintlere bolunur. Bu bir TAHMINDIR: trafik, sari bayrak, yagmur,
rakip stratejisi ve yaris bitis kurallari hesaba katilmaz."""
import math


def _v(x, lo, hi):
    if x is None:
        return None
    try:
        x = float(x)
    except (TypeError, ValueError):
        return None
    return x if math.isfinite(x) and lo <= x <= hi else None


def plan_strategy(fuel, rate, laps_left=None, time_left_s=None, lap_time_s=None, capacity=None,
                  reserve_laps=1.0, mandatory_stops=0, pit_loss_s=None, fuel_flow_lps=None,
                  tyre_time_s=None, current_lap=None):
    fuel = _v(fuel, 0, 1000)
    rate = _v(rate, 0.001, 200)
    laps_left = _v(laps_left, 0, 10000)
    time_left_s = _v(time_left_s, 0, 7 * 86400)
    lap_time_s = _v(lap_time_s, 5, 3600)
    capacity = _v(capacity, 1, 1000)
    reserve_laps = _v(reserve_laps, 0, 50)
    mandatory = int(_v(mandatory_stops, 0, 50) or 0)
    pit_loss_s = _v(pit_loss_s, 0, 600)
    fuel_flow_lps = _v(fuel_flow_lps, 0.05, 100)
    tyre_time_s = _v(tyre_time_s, 0, 300)
    source = 'laps'
    if laps_left is None and time_left_s is not None and lap_time_s is not None:
        laps_left = float(math.ceil(time_left_s / lap_time_s))     # zaman dolunca icinde bulunulan tur biter
        source = 'time'
    if fuel is None or rate is None or laps_left is None or reserve_laps is None:
        return None
    laps_left = int(math.ceil(laps_left))
    reserve = reserve_laps * rate
    needed = laps_left * rate + reserve
    warnings = []
    plan = {'source': source, 'laps_left': laps_left, 'fuel': fuel, 'rate': rate, 'reserve_l': reserve,
            'range_laps': fuel / rate, 'needed': needed, 'shortfall': max(0.0, needed - fuel),
            'surplus': max(0.0, fuel - needed), 'capacity': capacity, 'mandatory': mandatory,
            'stops': 0, 'stints': [], 'first_window': None, 'pit_time_total_s': 0.0,
            'fuel_save': None, 'warnings': warnings, 'feasible': True}

    first_max = max(0, int(math.floor((fuel - reserve) / rate)))
    if fuel >= needed and mandatory == 0:
        return plan                                            # pit gerekmez
    if capacity is None:
        warnings.append('capacity_unknown')
        plan['feasible'] = fuel >= needed
        plan['stops'] = mandatory
        return plan
    full = int(math.floor((capacity - reserve) / rate))        # dolu depoyla stint (tur)
    if full < 1:
        warnings.append('capacity_too_small')
        plan['feasible'] = False
        return plan
    first_max = min(first_max, laps_left)
    remaining = laps_left - first_max
    need_k = int(math.ceil(remaining / float(full))) if remaining > 0 else 0
    k = max(need_k, mandatory)
    plan['stops'] = k
    if k == 0:
        return plan
    # esit stintler: ilk stint yakit izin verdigi kadar, geri kalan esit bolunur
    s0 = min(first_max, int(math.ceil(laps_left / float(k + 1))))
    while True:
        rest = laps_left - s0
        segs = [rest // k + (1 if i < rest % k else 0) for i in range(k)]
        if max(segs) <= full or s0 >= first_max:
            break
        s0 += 1
    if max(segs) > full:
        warnings.append('not_enough_with_planned_stops')
        plan['feasible'] = False
    arrival = fuel - s0 * rate
    if arrival < reserve - 1e-9:
        warnings.append('below_reserve_now')                   # zaten guvenlik payinin altindasin: hemen pit
    cum, stints = s0, []
    for i, seg in enumerate(segs):
        fill_to = min(capacity, seg * rate + reserve)
        add = max(0.0, fill_to - arrival)
        t = (pit_loss_s or 0.0)
        if fuel_flow_lps:
            refuel_t = add / fuel_flow_lps
            t += max(refuel_t, tyre_time_s or 0.0)             # lastik degisimi yakitla ayni anda
        elif tyre_time_s:
            t += tyre_time_s
        stints.append({'stop': i + 1, 'pit_after_laps': cum, 'pit_lap': (current_lap + cum) if current_lap is not None else None,
                       'add_l': add, 'next_stint_laps': seg, 'pit_time_s': t if (pit_loss_s or fuel_flow_lps or tyre_time_s) else None})
        arrival = fill_to - seg * rate
        cum += seg
    plan['stints'] = stints
    plan['pit_time_total_s'] = sum(s['pit_time_s'] or 0.0 for s in stints)
    latest = first_max
    earliest = max(0, laps_left - k * full)
    plan['first_window'] = {'earliest': min(earliest, latest), 'latest': latest,
                            'earliest_lap': (current_lap + min(earliest, latest)) if current_lap is not None else None,
                            'latest_lap': (current_lap + latest) if current_lap is not None else None}
    # bir stop eksik: kac litre tasarruf gerekir?
    if k - 1 >= mandatory and k >= 1:
        total = fuel + (k - 1) * (capacity - reserve) - reserve
        need_rate = total / laps_left
        if need_rate > 0:
            save = max(0.0, 1.0 - need_rate / rate)
            plan['fuel_save'] = {'target_rate': need_rate, 'save_pct': save * 100.0, 'feasible': need_rate >= rate * 0.5,
                                 'time_gain_s': (stints[-1]['pit_time_s'] if stints[-1]['pit_time_s'] is not None else None)}
    return plan
