# -*- coding: utf-8 -*-
"""PitApex pedal teşhisi.

Oyunu (Assetto Corsa, ACC, LMU, iRacing...) AÇ, pistte ol, gaz/fren yap; sonra bu dosyayı çalıştır
(4_pedal_tani.bat). Pedal sisteminin neden çalışmadığını gösteren bir rapor yazar ve pedal_tani.txt
dosyasına kaydeder. Raporu bana gönderebilirsin; içinde kişisel bilgi yoktur (sadece program adları,
bellek durumu ve birkaç telemetri değeri)."""
import ctypes
import json
import os
import struct
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
OUT = []


def p(*a):
    line = " ".join(str(x) for x in a)
    print(line)
    OUT.append(line)


def section(title):
    p("")
    p("=== " + title + " ===")


def main():
    if os.name != "nt":
        p("Bu araç Windows içindir (oyunun paylaşımlı belleğini okur).")
        return
    from core.winmem import _MBI, k32, running_processes
    from telemetry import legacy_sources as LS

    section("1) Sistem")
    p("Python", sys.version.split()[0], "-", struct.calcsize("P") * 8, "bit")

    section("2) Çalışan oyun programları")
    procs = running_processes()
    found = [(exe, g) for exe, g in LS.PROC_GAMES if exe in procs]
    found += [(x, "iRacing") for x in sorted(procs) if x.startswith("iracingsim")]
    if found:
        for exe, g in found:
            p("  %-26s -> %s" % (exe, g))
    else:
        p("  Tanınan hiçbir oyun programı bulunamadı. (acs.exe / AC2-Win64-Shipping.exe / "
          "Le Mans Ultimate.exe / iRacingSim64DX11.exe)")
    p("  Otomatik algılama seçimi:", LS.probe_games())

    section("3) Oyun belleği (paylaşımlı bellek) haritaları")
    for name in ("Local\\acpmf_physics", "Local\\acpmf_graphics", "Local\\acpmf_static",
                 "Local\\IRSDKMemMapFileName", "$rFactor2SMMP_Telemetry$"):
        h = k32.OpenFileMappingW(0x4, False, name)
        if not h:
            p("  %-30s YOK (Windows hata %d)" % (name, ctypes.get_last_error()))
            continue
        ptr = k32.MapViewOfFile(h, 0x4, 0, 0, 0)
        size = "?"
        if ptr:
            mbi = _MBI()
            if k32.VirtualQuery(ptr, ctypes.byref(mbi), ctypes.sizeof(mbi)):
                size = int(mbi.RegionSize)
            k32.UnmapViewOfFile(ptr)
        k32.CloseHandle(h)
        p("  %-30s VAR, boyut: %s bayt" % (name, size))
    p("  (Fizik sayfası: Assetto Corsa ~580 bayt+, ACC daha büyük; ikisi de sayfa yuvarlamasıyla 4096 görünebilir.)")

    section("4) Fizik verisi okuma (0,5 sn arayla iki örnek)")
    for cls in (LS.ACSource, LS.ACCSource):
        src = cls()
        a = src.read()
        time.sleep(0.5)
        b = src.read()
        p("  Kaynak %-4s durum: %s" % (cls.NAME, src.status))
        if not a or not b:
            p("    veri okunamadı")
        else:
            changing = a["packetId"] != b["packetId"]
            p("    packetId: %s -> %s  (%s)" % (a["packetId"], b["packetId"],
                                                "AKIYOR" if changing else "DONMUS: oyun duraklatılmış/menüde olabilir"))
            p("    gaz=%.2f fren=%.2f hız=%.0f km/h abs=%.2f tc=%.2f vites=%s geçerli=%s" % (
                b["gas"], b["brake"], b["speed"], b["abs"], b["tc"], b["gear"], b["valid"]))
            p("    kayma oranları (ön sol, ön sağ, arka sol, arka sağ):",
              ["%.2f" % x for x in b["slipRatio"]])
        src.close()
    p("  İpucu: bu bölüm çalışırken fren/gaza bas; değerler değişmiyorsa oyun veri göndermiyor demektir.")

    section("5) Kayıtlı pedal ayarları")
    try:
        from storage.paths import get_documents_dir
        docs = get_documents_dir()
        for root in ("PitApex", "PitCore"):
            f = os.path.join(docs, root, "settings", "pedal_settings.json")
            if os.path.isfile(f):
                with open(f, encoding="utf-8") as fh:
                    d = json.load(fh)
                p("  %s: kaynak=%s, otomatik algıla=%s" % (f, d.get("_source"), d.get("_auto")))
                for k in ("abs", "lock", "tc", "slip"):
                    if k in d:
                        p("    %-5s açık=%s şiddet=%s motorlar=%s" % (k, d[k].get("enabled"),
                                                                   d[k].get("intensity"), d[k].get("motors")))
                break
        else:
            p("  Ayar dosyası bulunamadı (ilk açılış olabilir).")
    except Exception as e:
        p("  Okunamadı:", e)

    section("6) Seri portlar")
    try:
        import serial.tools.list_ports as lp
        ports = list(lp.comports())
        if not ports:
            p("  Hiç seri port yok: Arduino USB'de takılı mı, veri kablosu mu?")
        for x in ports:
            p("  %s - %s" % (x.device, x.description))
    except Exception as e:
        p("  pyserial okunamadı:", e)


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        p("TEŞHİS ARACI HATA VERDİ:", repr(exc))
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pedal_tani.txt")
    try:
        with open(path, "w", encoding="utf-8") as fh:
            fh.write("\n".join(OUT) + "\n")
        print("\nRapor kaydedildi:", path)
    except OSError:
        pass
    try:
        input("\nKapatmak için Enter'a bas...")
    except EOFError:
        pass
