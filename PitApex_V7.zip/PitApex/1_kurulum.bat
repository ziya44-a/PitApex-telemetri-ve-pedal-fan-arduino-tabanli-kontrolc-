@echo off
cd /d "%~dp0"
echo PitApex gerekli Python kutuphaneleri kuruluyor...
echo NOT: Bu adimda paket indirmek icin internet gerekebilir.
where py >nul 2>&1
if errorlevel 1 (
  echo HATA: Python launcher bulunamadi. Python kurup tekrar deneyin.
  pause
  exit /b 1
)
py -m pip install -r "%~dp0requirements.txt"
if errorlevel 1 (
  echo.
  echo HATA: Kurulum tamamlanamadi. Yukaridaki mesaji kontrol edin.
  pause
  exit /b 1
)
echo.
echo Kurulum tamamlandi. Simdi 2_baslat.bat dosyasini acabilirsiniz.
pause
