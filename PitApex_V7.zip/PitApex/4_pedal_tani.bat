@echo off
cd /d "%~dp0"
echo PitApex pedal teshisi: oyunu ac, pistte ol, gaz/fren yap, sonra bir tusa bas.
pause
py tools\pedal_tani.py
