@echo off
cd /d "%~dp0"
where py >nul 2>&1
if errorlevel 1 (
  echo HATA: Python launcher bulunamadi. Python kurup tekrar deneyin.
  pause
  exit /b 1
)
py -c "import serial; from PIL import Image, ImageTk" >nul 2>&1
if errorlevel 1 (
  echo HATA: PitApex icin gerekli Python kutuphaneleri eksik.
  echo Lutfen once 1_kurulum.bat dosyasini calistirin.
  echo Alternatif: py -m pip install -r requirements.txt
  pause
  exit /b 1
)
py "%~dp0main.py"
if errorlevel 1 pause
