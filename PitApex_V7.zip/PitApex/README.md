## Windows kurulumu (V7 Deneysel - Pist Haritalari)

1. ZIP arsivini tamamen ayri bir klasore cikarin.
2. Python ve `py` launcher kurulu olmali.
3. **Ilk kurulumda `1_kurulum.bat` dosyasini calistirin.** Bu dosya `requirements.txt` icindeki `pyserial` ve `Pillow` kutuphanelerini yukler. Ilk kurulumda internet gerekebilir.
4. Kurulum bittikten sonra `2_baslat.bat` ile PitApex'i acin.
5. `No module named 'PIL'` hatasi alirsaniz `1_kurulum.bat` dosyasini tekrar calistirin.
6. Uygulamanin pist haritalari calisirken internet baglantisi gerekmez; internet yalnizca ilk Python paket kurulumu icin gerekebilir.

Alternatif kurulum: `py -m pip install -r requirements.txt`

---

# PitApex V7 Deneysel

Pedal titreşimi + hıza bağlı fan + oyun bilgileri + kalıcı rekorlar. Windows, Python 3.

## Çalıştırma
1. `1_kurulum.bat` (pyserial kurar, bir kez)
2. `2_baslat.bat` (uygulamayı açar)
3. İsteğe bağlı: `3_exe_olustur.bat` → tek dosya `PitApex.exe`

**Eski ayarların:** İlk açılışta `ayarlar.json` ve `profiller\` klasörü, PitApex klasörünün yanında ya da yanındaki `PedalHaptic` klasöründe bulunursa `Belgeler\PitApex` altına **kopyalanır** (eskiler silinmez, bir kez yapılır).

## Arduino (ÖNEMLİ)
`firmware/PedalHaptic/PedalHaptic.ino` dosyasını Arduino'ya yeniden yükle (v3). Pedal kodu aynı kaldı, sadece fan eklendi.
Eski v2 kodla pedaller çalışmaya devam eder; yalnızca fan çalışmaz ve arayüz bunu açıkça yazar.

- Fan varsayılan **M3**'te. M4 için `.ino` içinde `#define FAN_MOTOR 4`.
- Fan PWM'i sabit ~1 kHz'dir. 8/64 kHz seçenekleri Timer0'ı değiştirip `millis()/micros()` zamanlamasını bozacağı için bilerek kullanılmadı.
- Fan komutu `F,<0-255>`. Pedal motorlarının 150 ms zaman aşımı fana uygulanmaz; fanın ayrı 2 sn zaman aşımı vardır (USB kopar/program kapanırsa fan durur).
- **Donanım:** L293D kanal başına ~0,6 A sürekli verir. 12 V, 0,1-0,3 A'lik 2-3 telli fan uygundur. Büyük kasa fanları ve 4 telli PWM fanlar doğrudan bağlanmamalı (harici MOSFET gerekir).

## Sayfalar
- **Pedallar:** 9 efekt, her biri bağımsız kutucuklu kart (kapalıyken yalnız ad; açılınca motor gücü, min/max güç, frekans, eşik, süre, hassasiyet açılır). Yeni: **Fren limiter** (eşik + histerezis), **Vites yükseltme / düşürme** (vites değişimi tek olay). Efekt kapanınca çıkışı anında sıfırlanır. Motor ince ayarı ve profiller korunur. Efekt hesabı ve ana döngü eski koddan birebir taşındı.
- **Fan:** rölanti / orta nokta / maksimum hız eğrisi (varsayılan: 0 km/h %25, 150 km/h %50, 300 km/h %100), güç sınırı, min PWM, kalkış darbesi, yumuşatma, test, canlı eğri önizlemesi. Telemetri yokken "dur" ya da "rölantide kal" seçilir. Hız bilgisi pedal motorunun okuduğu oyundan gelir; pedal efektleri kapalıyken de çalışır.
- **Oyun Bilgileri:** ● canlı, ◆ kayıtlı geçmiş, "Veri alınamıyor" olarak üç ayrı görünüm. **Oturum saklama:** oyun kapansa ya da telemetri kesilse son oturumun tüm verileri (araç, pist, turlar, hız, yakıt, lastik...) ◆ olarak ekranda kalır; uygulama yeniden açılınca da son oturum gösterilir. Yeni oturum başlayınca eskisi arşive geçer (silinmez). Telemetri kesintisi oturumu bitirmez; oyun kapanışı bitirir.
- **Kaydedilen Rekorlar:** Oyun → Pist → Araç modeli.
- **⚙ Ayarlar:** tema (siyah/beyaz), veri klasörü, en altta **Tehlikeli İşlemler** (SİL yazma + ikinci onay).

## Veri
`Belgeler\PitApex\` (OneDrive'a taşınmış Belgeler dahil gerçek yolu bulur): `records`, `sessions`, `settings`, `profiles`, `backups`. Atomik yazma (geçici dosya → `fsync` → `os.replace`), 5 dakikada bir en fazla yedek (son 10 tutulur), bozuk dosya silinmeden yan tarafa alınıp yedekten geri yüklenir.
"Tüm verileri temizle" yalnızca bu klasörün içeriğini siler, program dosyalarına dokunmaz.

## Telemetri doğruluk ilkesi
Bir alan oyundan okunamıyorsa, 0 geliyorsa (oyunlar yoksa 0 doldurur), mantık aralığı dışındaysa ya da yapı doğrulanamıyorsa **"Veri alınamıyor"** yazılır. Hiçbir yerde tahmin üretilmez (LMU/iRacing TC-ABS kayma oranından tahmin edilmez).

| | ACC | AC | LMU | iRacing |
|---|---|---|---|---|
| Pist / araç | ✔ | ✔ (layout dahil) | ✔ (araç adı livery içerebilir) | ✔ |
| Tur süresi | ✔ | ✔ | ✔ (iki kaynakla çapraz doğrulama) | ✔ (oyun saatiyle çapraz doğrulama) |
| Sektörler | ✔ doğrulanırsa | ✔ 3 sektörlü pistlerde, doğrulanırsa | ✔ doğrulanırsa | ✘ (oyun vermiyor) |
| Tur geçerliliği | ✔ oyundan | ✘ (pit/şüpheli filtresi) | ✘ (pit filtresi) | ✘ (pit filtresi) |
| Yakıt | ✔ | ✔ | ✔ | ✔ |
| Lastik ısı / basınç | ✔ | ✔ | ✔ | yalnızca pit yolunda |
| Su / yağ | su ✔, yağ ✘ | ✘ / ✘ | ✔ / ✔ | ✔ / ✔ |
| ABS / TC aktivitesi | ✔ / ✔ | ✔ / ✔ | ✘ / ✘ | ✔ / ✘ |
| ABS / TC ayar seviyesi | ✔ / ✔ | ✘ / ✘ | ✘ / ✘ | araç destekliyorsa |

Tur olayları: **tamamlanma** (oyun tur sayacı +1), **sıfırlama** (sayaç geriye gider ya da tur saati aynı sayaçta başa döner: pite dönüş / tur yeniden başlatma) ve **başlangıç** (her olayda yeni, boş tur durumu; eski turun bayrakları, saati, sektörleri taşınmaz). Tur saati hiç sıfırlanmıyorsa (20 dk üstü) o tur "aşırı uzun" sayılıp kaydedilmez.

Rekor yalnızca şu koşullarda yazılır: tur, PitApex tur başında ya da sonrasında açıkken tamamlandı; pit yolu kullanılmadı; oyun geçersiz saymadı; süre oyundan okundu ve çapraz doğrulama geçti. Oyun geçerlilik bilgisi vermiyorsa kayıt **"Doğrulanmamış"** etiketiyle saklanır. Sektör süreleri doğrulanamazsa boş bırakılır (S1+S2+S3, tur süresine ±2 ms uymuyorsa hepsi atılır).

## Gerçek oyunla doğrulanması gerekenler
Buradaki test ortamında oyun ve gerçek Tk yoktu. Bellek yapıları resmi belgelere ve bilinen boyutlara göre yazıldı (LMU yapı boyutları bilinen değerlerle birebir tutuyor), mantık yapay verilerle test edildi, **ama gerçek oyunla ilk kullanımda şunlara bak:**
1. Her oyunda pist/araç adı doğru mu? (rekor anahtarı bunlardır)
2. Bir tur at: tur süresi oyunun gösterdiğiyle aynı mı? Sektörler doğru mu, yoksa "—" mi?
3. Pit çıkış/giriş turu ve geçersiz tur rekora **yazılmıyor** mu?
4. Lastik/yakıt/su değerleri oyun içi göstergeyle uyuşuyor mu? Uyuşmayan alan varsa söyle, o alanı kapatırız.
5. LMU: araç adında yarış numarası/livery varsa aynı araç farklı kayıt olabilir.
6. ACC "Veri yapısı uyuşmuyor" yazarsa ilgili alanlar zaten gizlenir; bana haber ver.

## Testler
```
py -m unittest discover -s tests -t .
```
(116 test: depolama, rekor mantığı, tur/sektör takibi, pedal efektleri (fren limiter, vites yükseltme/düşürme), ACC/AC/iRacing/LMU okuyucuları, fan.)
Sahte Tk duman testi: `set PYTHONPATH=tests\fake_tk` ardından `py tests\smoke_ui.py`.


## PitApex oyun telemetrisi ve overlay'ler

Oyun Bilgileri modülü dört oyunu ayrı adaptörlerle okur: ACC, AC, LMU ve iRacing. Bu sürümde kullanılan kaynaklar UDP değil, oyunların yerel paylaşımlı bellek arayüzleridir: AC/ACC `acpmf_*`, LMU `rFactor2SMMP` ve iRacing `IRSDKMemMapFileName`. Bu nedenle UDP paket boyutu varsayımı yapılmaz; her adaptör kendi bellek başlığını, yapı boyutlarını ve alan sınırlarını doğrular. Desteklenmeyen veya doğrulanamayan alanlar `None` kalır.

Oturumlar oyun kimliği + pist + araç ayrımında saklanır. Oyun değiştiğinde mevcut oturum kapatılıp kaydedilir; diğer oyunun telemetrisi önceki oturuma aktarılmaz. Pedal efekt motoru ve oyun bilgileri telemetri işçisi ayrı iş parçacıklarında çalışır.

`Overlay Yönetimi` sekmesinden hız, pedal, devir/vites ve tur bilgisi pencereleri bağımsız açılabilir; birden fazla overlay aynı anda kullanılabilir. Pencereler sol tuşla taşınır, sağ tıkla kapatılır ve konumları tercih dosyasında saklanır.


## Motor çıkışları (M1-M4) ve iki fan
- **Pedal efektleri:** her efektte motor seçilir (M1-M4). İlk motoru seçince altında **＋ Motor ekle** çıkar: aynı efekt birden çok motoru
  sürebilir (örn. ABS için M1 + M2). Ek satırlar ✕ ile kaldırılır; aynı efekte aynı motor iki kez seçilemez. Her motorun (M1-M4) min/max gücü ayrıdır.
  Eski ayar dosyaları ve profiller (`motor: 0/1/2`) otomatik okunur.
- **Fan sayfası:** iki fan yuvası. Üstte tablo (Açık / Çıkış / Durum), altta her fan için ayrı sekme: kendi çıkışı, hız eğrisi, ince ayarı ve testi.
  Eski tek fanlı ayar Fan 1'e (M3) taşınır; Fan 2 varsayılan M4, kapalı.
- **Çakışmalar:** aynı çıkış hem pedal efektinde hem fanda ya da iki fanda seçilirse uyarı çıkar (bir çıkışa tek cihaz bağlanmalı).
- **Arduino kodu v4 gerekir** (`firmware/PedalHaptic/PedalHaptic.ino`'yu yeniden yükle): M3/M4 titreşim motoru ve fan çıkış seçimi/ikinci fan.
  Kod v3 ise M1/M2 pedal ve tek fan çalışır (çıkışı kodda sabit), arayüz uyarır. M3/M4 PWM frekansı sabit 1 kHz'dir; yalnız M1/M2 için seçilebilir.
- Test: `tests/test_motor_outputs.py`, Arduino kodunu ana makinede (g++ ile, `tests/firmware_sim`) derleyip komut/zaman aşımı senaryolarıyla dener.
  Gerçek Arduino, L293D ve fanlarla denenmedi.

## LED Aydınlatma sekmesi (MAX7219 8×8 LED matris)
- **Ayrı Arduino:** LED kartı pedal/fan Arduino'sundan bağımsızdır; sayfanın kendi port seçimi, Bağlan/Kes düğmesi ve "Açılışta otomatik bağlan" seçeneği var.
  Arduino'ya `firmware/LedMatrix/LedMatrix.ino` yüklenir (Arduino IDE'de **LedControl** kütüphanesi gerekir).
  Varsayılan bağlantı: VCC→5V, GND→GND, DIN→D12, CLK→D11, CS→D10 (`PIN_*` satırlarından değişir; zincirli modül için `NUM_DEVICES`).
- **İlk özellik: vites göstergesi.** R, N, 1-9 (10 ve üstü '+'). N için "N harfi / 0 rakamı", oyun verisi yokken "boş / çizgi" seçilir.
  Vites, pedal sayfasındaki seçili/algılanan oyundan gelir; oyun verisi yoksa vites uydurulmaz. Yeni LED özellikleri `core/led_matrix.py` içindeki `FEATURES` listesine eklenir.
- **Ekran ayarları:** parlaklık (0-15), dönme (0/90/180/270), yatay/dikey ayna. Modül kablolamaları farklı olduğu için yön PC tarafında ayarlanır
  ("Yön testi (R)" ile harf düzgün görünene kadar). Canlı önizleme ve "tüm LED'ler açık" testi var.
- **Güvenlik:** PC kapanır ya da USB kopar ise LED kartı 3 sn sonra ekranı temizler. LED portuna yanlışlıkla pedal/fan Arduino'su bağlanırsa arayüz bunu söyler;
  pedal/fan ile aynı port seçilemez.
- Protokol: `D,<16 hex>` görüntü (8 satır), `B,<0-15>` parlaklık, `C` temizle, `V` → `LED1`. Test: `tests/test_led.py` (Arduino kodunu g++ ile derleyip simüle eder).
  **Gerçek MAX7219 modülle denenmedi:** özellikle yön ayarı ve parlaklık davranışı ilk denemede gözden geçirilmeli.

## Logo
Resmî PitApex logosu `assets/pitapex_logo.png` olarak eklendi. Pencere ve EXE simgesi `assets/pitapex.ico`; üst başlık simgesi `assets/logo_56.png` kullanır. EXE simgesini güncellemek için `3_exe_olustur.bat` yeniden çalıştırılmalıdır.

## Sürüm
V7 Deneysel — çevrimdışı pist meta verileri, lastik analizi ve yakıt stratejisi. Pist çizim koordinatları henüz dahil değildir.
