# PitApex V7 Deneysel - Çevrimdışı pist haritaları

- Yeni **Pist Haritası** sekmesi eklenmiştir.
- Haritalar `assets/offline_maps` içinde yerel PNG dosyalarıdır; harita görüntüleme modülü internet erişimi kullanmaz.
- iRacing arşivinden 424 konfigürasyon görseli; RaceStudio3 arşivinden 23 ACC konfigürasyonu için seçilmiş görseller üretilmiştir. Toplam 447 görsel.
- Eşleştirmeler `assets/offline_maps/index.json` dosyasındadır. Aynı görseller AC ve LMU için de yalnızca eşleşen pist kimlikleriyle kullanılabilir.
- **Canlı araç işaretçisi yoktur.** SVG görüntüsünün gerçek telemetri mesafesi/koordinatlarıyla kalibrasyonu henüz yapılmadı.
- iRacing çoklu pist düzenleri için `track_id|config` kimliklerinin gerçek oyundaki biçimi doğrulanmalıdır; belirsiz konfigürasyonda otomatik harita seçilmez.
- Tüm ACC/AC/LMU pistleri kapsanmıyor; eşleşmeyenlerde 'harita yok' gösterilir.
- Otomatik test: 297/297 başarılı (kaynak kodu seviyesinde). Windows GUI, gerçek oyun, Arduino ve tüm uygulamanın ağ trafiği test edilmedi.
- Kaynak haritaların yeniden dağıtım lisansı arşivde açık biçimde belirtilmemiştir. Açık kaynak GitHub yayını öncesinde hakları ayrıca doğrulayın.
