OFFLINE TRACK MAP LIBRARY
This folder contains locally bundled track geometry only. No map download, recording, or track learning.
Expected path: tracks/<game>/<track_id>.json
Format: {"name":"Track configuration", "points":[[x,y],[x,y],[x,y]], "start_index":0}
Points must represent a real, verified circuit centerline in driving order. Map progress alignment must be verified separately.
NO VERIFIED TRACK GEOMETRY IS INCLUDED IN THIS RELEASE. The loader intentionally returns None for missing tracks.
