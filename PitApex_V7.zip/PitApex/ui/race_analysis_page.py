"""PitApex live tyre monitor and offline manual/automatic fuel strategy (TR/EN)."""
import tkinter as tk
from tkinter import ttk
from core import strategy_runtime
from core.fuel_tracker import BASES, BASIS_LABELS
from ui.i18n import translate

class RaceAnalysisPage(ttk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        self.tyre_labels = []
        tyres = ttk.LabelFrame(self, text='Lastik performans analizi / Tyre analysis')
        tyres.pack(fill='x', padx=12, pady=8)
        for name in ('Sol ön / FL', 'Sağ ön / FR', 'Sol arka / RL', 'Sağ arka / RR'):
            row = ttk.Frame(tyres)
            row.pack(fill='x', padx=8, pady=5)
            ttk.Label(row, text=name, width=17).pack(side='left')
            label = ttk.Label(row, text='—')
            label.pack(side='left')
            self.tyre_labels.append(label)
        self.tyre_note = ttk.Label(tyres, text='', wraplength=750)
        self.tyre_note.pack(anchor='w', padx=8, pady=7)
        strategy = ttk.LabelFrame(self, text='Yakıt ve pit stop stratejisi / Fuel & pit strategy')
        strategy.pack(fill='x', padx=12, pady=8)
        self.inputs = {}
        fields = [
            ('fuel', 'Mevcut yakıt (L) / Fuel', ''),
            ('rate', 'Tüketim (L/tur) / L/lap', ''),
            ('laps', 'Kalan tur / Laps left', ''),
            ('minutes', 'Kalan süre (dk) / Minutes left', ''),
            ('lap_seconds', 'Tur süresi (sn) / Lap seconds', ''),
            ('reserve', 'Güvenlik payı (tur) / Reserve laps', '1'),
            ('capacity', 'Depo kapasitesi (L) / Tank capacity', ''),
            ('pit_loss', 'Pit kaybı (sn) / Pit loss', ''),
            ('flow', 'Yakıt dolum hızı (L/sn) / Refuel rate', ''),
            ('tyre', 'Lastik değişim süresi (sn) / Tyre change', ''),
            ('mandatory', 'Zorunlu pit / Mandatory stops', '0'),
        ]
        saved = self.app.overlays.strategy_inputs() if hasattr(self.app, 'overlays') else dict(strategy_runtime.DEFAULT_INPUTS)
        for index, (key, label, default) in enumerate(fields):
            r, c = divmod(index, 2)
            cell = ttk.Frame(strategy)
            cell.grid(row=r, column=c, sticky='w', padx=9, pady=5)
            ttk.Label(cell, text=label, width=37).pack(side='left')
            var = tk.StringVar(value=saved.get(key, default))
            ttk.Entry(cell, textvariable=var, width=11).pack(side='left', padx=4)
            self.inputs[key] = var
        cell = ttk.Frame(strategy)
        cell.grid(row=5, column=1, sticky='w', padx=9, pady=5)
        ttk.Label(cell, text='Tüketim hesabı / Consumption basis', width=37).pack(side='left')
        self.basis_var = tk.StringVar(value=BASIS_LABELS[saved.get('basis', 'avg5')])
        ttk.Combobox(cell, values=[BASIS_LABELS[b] for b in BASES], textvariable=self.basis_var, width=20,
                     state='readonly').pack(side='left', padx=4)
        self._saved_snapshot = None
        ttk.Label(strategy, text='Boş alan = otomatik telemetri (varsa). Manuel değer önceliklidir.').grid(row=6, column=0, columnspan=2, sticky='w', padx=9, pady=6)
        self.fuel_result = ttk.Label(strategy, text='—', justify='left')
        self.fuel_result.grid(row=7, column=0, columnspan=2, sticky='w', padx=10, pady=8)
        self.fuel_note = ttk.Label(strategy, text='', wraplength=750)
        self.fuel_note.grid(row=8, column=0, columnspan=2, sticky='w', padx=10, pady=8)
        self.refresh_language()

    def refresh_language(self):
        from ui.i18n import apply_language
        apply_language(self, self.app.language)

    def _number(self, key):
        value = self.inputs[key].get().strip().replace(',', '.')
        if not value:
            return None
        try:
            number = float(value)
            return number if __import__('math').isfinite(number) else None
        except ValueError:
            return None

    def tick(self, visible):
        if not visible:
            return
        en = self.app.language == 'en'
        tr = lambda a, b: b if en else a
        analysis = self.app.race_analysis
        f = analysis.latest
        for i, label in enumerate(self.tyre_labels):
            if not f:
                label.configure(text=tr('Veri bekleniyor', 'Waiting for telemetry'))
                continue
            temp = ((f.tyre_temp_c or []) + [None]*4)[i]
            pressure = ((f.tyre_press_kpa or []) + [None]*4)[i]
            wear = ((f.tyre_wear_raw or []) + [None]*4)[i]
            trend = analysis.tyre_trend(i)
            fields = [tr('Sıcaklık: ', 'Temperature: ') + ('%.1f °C' % temp if temp is not None else '—'),
                      tr('Basınç: ', 'Pressure: ') + ('%.2f PSI' % (pressure / 6.894757) if pressure is not None else '—'),
                      tr('Aşınma (ham): ', 'Wear (raw): ') + ('%.3f' % wear if wear is not None else '—'),
                      tr('Isı eğilimi: ', 'Temp trend: ') + ('%+.1f °C' % trend if trend is not None else '—')]
            label.configure(text='  |  '.join(fields))
        self.tyre_note.configure(text=tr('Aşınma değeri oyunun ham birimidir; yüzde değildir. Bazı oyunlarda lastik verileri yalnızca pit sırasında yenilenir.',
                                         'Wear uses game-native units, not percentages. Some games refresh tyre measurements only in the pits.'))
        values = {k: v.get() for k, v in self.inputs.items()}
        inv = {v: k for k, v in BASIS_LABELS.items()}
        values['basis'] = inv.get(self.basis_var.get(), 'avg5')
        if values != self._saved_snapshot and hasattr(self.app, 'overlays'):
            self._saved_snapshot = dict(values)
            self.app.overlays.set_strategy_inputs(values)       # overlay ayni degerleri kullanir
        tracker = getattr(analysis, 'fuel', None)
        plan, src = strategy_runtime.build_plan(f, tracker, values)
        self.fuel_result.configure(text=strategy_runtime.plan_text(plan, src, tracker, self.app.language))
        self.fuel_note.configure(text=tr('Boş alanlar otomatik doldurulur (oyun verisi ya da ölçülen temiz tur ortalaması). Elle girilen değer önceliklidir. '
                                         'Aynı değerleri "Yakıt / Pit stratejisi" overlay\'i de kullanır. Hesap çevrimdışıdır.',
                                         'Empty fields are filled automatically (game data or measured clean-lap average). Manual values win. '
                                         'The "Fuel / Pit strategy" overlay uses the same values. Calculation is offline.'))
