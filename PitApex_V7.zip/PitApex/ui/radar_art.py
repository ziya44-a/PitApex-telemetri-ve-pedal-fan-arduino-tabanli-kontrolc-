"""Radar overlay'i icin saf geometri ve renk mantigi (Tk'dan bagimsiz, test edilebilir).

 * threat_hex: 10 m'de SARI -> 5 m'de KIRMIZI, arasi turuncu uzerinden renk gecisli.
 * car_shapes: ustten GT arac silueti (govde, camlar, tekerlekler, farlar, arka kanat) cokgen listesi olarak.
 * sector_arcs: bir yondeki uyari yaylari (park sensoru gibi), en yakin aractaki mesafeye kadar.
Bu modulun hicbir renginde pencerenin saydam anahtar rengi (#151515) kullanilmaz."""
import math

from core.proximity_radar import WARN_RED_M, WARN_YELLOW_M, threat_ratio

YELLOW, ORANGE, RED = (255, 214, 10), (255, 138, 22), (255, 52, 52)
NEUTRAL_CAR = "#aab3bf"
PLAYER_CAR = "#35ee6b"
SHADOW = "#0a0c0f"
GLASS = "#0f1822"


def _lerp(a, b, t):
    return tuple(int(round(a[i] + (b[i] - a[i]) * t)) for i in range(3))


def threat_rgb(ratio):
    """ratio 0 -> sari, 0.5 -> turuncu, 1 -> kirmizi. None -> None (uyari yok)."""
    if ratio is None:
        return None
    t = max(0.0, min(1.0, ratio))
    return _lerp(YELLOW, ORANGE, t * 2) if t < 0.5 else _lerp(ORANGE, RED, (t - 0.5) * 2)


def to_hex(rgb):
    return "#%02x%02x%02x" % tuple(max(0, min(255, int(v))) for v in rgb)


def threat_hex(distance, fallback=NEUTRAL_CAR):
    """Mesafeye (metre) gore renk. 10 m'den uzaksa fallback (uyari yok)."""
    rgb = threat_rgb(threat_ratio(distance))
    return fallback if rgb is None else to_hex(rgb)


def shade(hex_color, factor):
    """factor < 1 koyulastirir, > 1 acar."""
    c = hex_color.lstrip("#")
    if len(c) == 3:                      # "#fff" kisaltmasi
        c = "".join(ch * 2 for ch in c)
    rgb = [int(c[i:i + 2], 16) for i in (0, 2, 4)]
    return to_hex([v * factor if factor <= 1 else v + (255 - v) * (factor - 1) for v in rgb])


def chaikin(points, iterations=2):
    """Kapali cokgeni Chaikin ile yumusatir (Tk'nin smooth bayragina bagimli olmadan duzgun kenar)."""
    pts = list(points)
    for _ in range(iterations):
        out = []
        n = len(pts)
        for i in range(n):
            (x0, y0), (x1, y1) = pts[i], pts[(i + 1) % n]
            out.append((0.75 * x0 + 0.25 * x1, 0.75 * y0 + 0.25 * y1))
            out.append((0.25 * x0 + 0.75 * x1, 0.25 * y0 + 0.75 * y1))
        pts = out
    return pts


def _mirror(half):
    """Yarim ana hat (ust-orta -> alt-orta, sag taraf) -> tam kapali ana hat."""
    return list(half) + [(-u, v) for (u, v) in reversed(half[1:-1])]


_BODY = _mirror([(0.00, -1.00), (0.30, -0.98), (0.58, -0.90), (0.78, -0.75), (0.88, -0.52), (0.92, -0.25),
                 (0.92, 0.15), (0.90, 0.50), (0.82, 0.78), (0.62, 0.94), (0.30, 0.99), (0.00, 1.00)])
_GLASS = _mirror([(0.00, -0.42), (0.50, -0.34), (0.60, -0.12), (0.58, 0.30), (0.46, 0.46), (0.00, 0.50)])
_ROOF = _mirror([(0.00, -0.17), (0.36, -0.13), (0.40, 0.20), (0.00, 0.28)])


def car_shapes(cx, cy, length, width, body):
    """Ustten GT arac (on ust, arka alt). Cizim sirasiyla dict listesi:
    {'kind': 'polygon', 'points': [x, y, ...], 'fill': hex, 'outline': hex, 'width': n}."""
    hw, hl = width / 2.0, length / 2.0
    detail = width >= 9

    def tr(pts, sx=1.0, sy=1.0, ox=0.0, oy=0.0):
        return [coord for (u, v) in pts for coord in (cx + ox + u * hw * sx, cy + oy + v * hl * sy)]

    dark = shade(body, 0.55)
    edge = shade(body, 0.42)
    body_pts = chaikin(_BODY, 2)
    shapes = []
    # golge / koyu kenar halesi: okunurlugu her zeminde korur
    shapes.append({"kind": "polygon", "points": tr(body_pts, 1.16, 1.07), "fill": SHADOW, "outline": "", "width": 0})
    # tekerlekler
    ww, wl = 0.115 * width, 0.105 * length
    for su in (-1, 1):
        for v in (-0.58, 0.56):
            x, y = cx + su * 0.93 * hw, cy + v * hl
            shapes.append({"kind": "polygon", "points": [x - ww, y - wl, x + ww, y - wl, x + ww, y + wl, x - ww, y + wl],
                           "fill": "#15181d", "outline": "#05070a", "width": 1})
    # arka kanat (govdeden genis)
    if detail:
        wy = cy + 0.93 * hl
        shapes.append({"kind": "polygon", "points": [cx - 0.98 * hw, wy - 0.07 * hl, cx + 0.98 * hw, wy - 0.07 * hl,
                                                     cx + 0.98 * hw, wy + 0.07 * hl, cx - 0.98 * hw, wy + 0.07 * hl],
                       "fill": dark, "outline": edge, "width": 1})
    # govde
    shapes.append({"kind": "polygon", "points": tr(body_pts, 0.94, 1.0), "fill": body, "outline": edge, "width": 1})
    if detail:
        shapes.append({"kind": "polygon", "points": tr(chaikin(_GLASS, 1), 0.94, 1.0), "fill": GLASS,
                       "outline": "", "width": 0})
        shapes.append({"kind": "polygon", "points": tr(chaikin(_ROOF, 1), 0.94, 1.0), "fill": shade(body, 0.78),
                       "outline": "", "width": 0})
        # kaputta orta serit
        shapes.append({"kind": "polygon", "points": tr([(-0.045, -0.97), (0.045, -0.97), (0.045, -0.46), (-0.045, -0.46)]),
                       "fill": shade(body, 1.25), "outline": "", "width": 0})
        # farlar (acik) ve stop lambalari (kirmizi)
        for su in (-1, 1):
            shapes.append({"kind": "polygon", "points": tr([(su * 0.62, -0.86), (su * 0.34, -0.93), (su * 0.34, -0.85),
                                                           (su * 0.58, -0.78)]), "fill": "#fff3c4", "outline": "",
                           "width": 0})
            shapes.append({"kind": "polygon", "points": tr([(su * 0.56, 0.90), (su * 0.30, 0.94), (su * 0.30, 0.86),
                                                           (su * 0.52, 0.84)]), "fill": "#ff4545", "outline": "",
                           "width": 0})
    return shapes


# yon adlari: 0 = on, saat yonunde
SECTOR_NAMES = ("ÖN", "SAĞ ÖN", "SAĞ", "SAĞ ARKA", "ARKA", "SOL ARKA", "SOL", "SOL ÖN")


def arc_points(cx, cy, radius, a0, a1, steps=14):
    """Radar acisi: 0 = yukari (on), saat yonu. Poligon/cizgi noktalari (x, y duz liste)."""
    out = []
    for j in range(steps + 1):
        a = a0 + (a1 - a0) * j / float(steps)
        out.extend((cx + radius * math.sin(a), cy - radius * math.cos(a)))
    return out


def sector_arcs(nearest_distance):
    """Bir yondeki uyari yaylari: 10 m'den en yakin araca kadar 1 m aralikla, her yayin rengi o mesafeye gore.
    [(yaricap_metre, '#rrggbb'), ...] uzaktan yakina."""
    if nearest_distance is None or nearest_distance > WARN_YELLOW_M:
        return []
    arcs, r = [], WARN_YELLOW_M
    while r >= max(2.0, nearest_distance - 0.5):
        arcs.append((r, threat_hex(r)))
        r -= 1.0
    return arcs
