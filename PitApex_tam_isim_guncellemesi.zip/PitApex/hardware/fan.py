"""Hiza bagli fan kontrolu. Pedal motorundan BAGIMSIZ kendi ipliginde calisir; pedal efektleri
kapali olsa bile fan calisir. Hiz bilgisini yalnizca pedal motorunun okuma sonucundan (engine.snap)
SALT-OKUNUR alir; Arduino'ya ortak ArduinoLink uzerinden 'F,<0-255>' yazar."""
import threading
import time


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


def normalized(cfg):
    """Ayarlari guvenli araliklara getirir (kutuya yazarken gecici bozuk deger olabilir)."""
    def g(k, default):
        try:
            return float(cfg.get(k, default))
        except (TypeError, ValueError):
            return float(default)
    max_speed = clamp(g("max_speed", 300), 50, 600)
    return {
        "enabled": bool(cfg.get("enabled", False)),
        "idle_pct": clamp(g("idle_pct", 25), 0, 100),
        "mid_speed": clamp(g("mid_speed", 150), 1, max_speed - 1),
        "mid_pct": clamp(g("mid_pct", 50), 0, 100),
        "max_speed": max_speed,
        "max_pct": clamp(g("max_pct", 100), 10, 100),
        "min_pwm": clamp(g("min_pwm", 60), 0, 200),
        "kick_ms": clamp(g("kick_ms", 400), 0, 2000),
        "ramp_up": clamp(g("ramp_up", 60), 5, 1000),
        "ramp_down": clamp(g("ramp_down", 30), 5, 1000),
        "no_data": "idle" if cfg.get("no_data") == "idle" else "stop",
    }


def curve_pct(speed_kmh, cfg):
    """Hiz -> fan gucu (%): 0 km/h = rolanti, orta nokta, maks hiz = %100; aralarinda dogrusal.
    Sonuc 'max_pct' guc sinirini asamaz."""
    c = normalized(cfg)
    pts = [(0.0, c["idle_pct"]), (c["mid_speed"], c["mid_pct"]), (c["max_speed"], 100.0)]
    s = max(0.0, speed_kmh)
    if s >= pts[-1][0]:
        pct = pts[-1][1]
    else:
        pct = pts[0][1]
        for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
            if s <= x1:
                pct = y0 + (y1 - y0) * (s - x0) / (x1 - x0)
                break
    return min(pct, c["max_pct"])


def pct_to_pwm(pct, cfg):
    """% -> 0-255 PWM. 0 = durur; >0 ise fanin donmeye basladigi min_pwm'den baslar."""
    if pct <= 0.5:
        return 0
    c = normalized(cfg)
    pwm = c["min_pwm"] + (255 - c["min_pwm"]) * min(100.0, pct) / 100.0
    return int(clamp(round(pwm), 1, 255))


class FanController(threading.Thread):
    KEEPALIVE = 0.5

    def __init__(self, link, engine, cfg_getter):
        super().__init__(daemon=True)
        self.link = link
        self.engine = engine
        self.cfg_getter = cfg_getter
        self.running = True
        self.cur_pct = 0.0
        self.last_pwm_sent = None
        self.last_send = 0.0
        self.kick_until = 0.0
        self.out_pwm = 0
        self.test = None                       # (pct, bitis_zamani)
        self.status = {"text": "Kapalı", "level": "off", "speed": None, "pct": 0.0, "pwm": 0}
        self._t = time.monotonic()

    def start_test(self, pct, seconds=5.0):
        self.test = (float(pct), time.monotonic() + seconds)

    def stop_test(self):
        self.test = None

    # --- hedef ve durum ---
    def decide(self, cfg, now):
        """(hedef_yuzde, durum_metni, seviye, hiz). Hiz yoksa None."""
        link = self.link
        if not link.connected:
            return 0.0, "Arduino bağlı değil", "warn", None
        if not link.ready:
            return 0.0, "Arduino hazırlanıyor…", "warn", None
        if link.fw_version is None:
            return 0.0, "Arduino kod sürümü bekleniyor…", "warn", None
        if not link.fan_supported:
            return 0.0, "Arduino kodu eski (v%s). Fan için firmware/PedalHaptic.ino dosyasını yeniden yükleyin." \
                % link.fw_version, "bad", None
        if self.test and now < self.test[1]:
            return self.test[0], "Test: %%%.0f" % self.test[0], "ok", None
        self.test = None
        if not cfg["enabled"]:
            return 0.0, "Kapalı", "off", None
        snap = self.engine.snap or {}
        t = snap.get("t")
        speed = None
        if snap.get("live") and t and snap.get("valid", True):
            sp = t.get("speed")
            if isinstance(sp, (int, float)) and 0 <= sp < 700:
                speed = float(sp)
        if speed is None:
            if cfg["no_data"] == "idle":
                return cfg["idle_pct"], "Telemetri yok: fan rölantide", "warn", None
            return 0.0, "Telemetri yok: fan durduruldu", "warn", None
        pct = curve_pct(speed, cfg)
        return pct, "Aktif: %.0f km/h → %%%.0f" % (speed, pct), "ok", speed

    def tick(self, now):
        cfg = normalized(self.cfg_getter() or {})
        dt = max(0.0, min(0.5, now - self._t))
        self._t = now
        target, text, level, speed = self.decide(cfg, now)

        # yumusatma: ani siçrama olmasin
        if target > self.cur_pct:
            self.cur_pct = min(target, self.cur_pct + cfg["ramp_up"] * dt)
        else:
            self.cur_pct = max(target, self.cur_pct - cfg["ramp_down"] * dt)
        if target == 0.0 and self.cur_pct < 1.0:
            self.cur_pct = 0.0

        pwm = pct_to_pwm(self.cur_pct, cfg)
        # kick-start: duruştan kalkarken kisa sure tam guc (cogu fan dusuk PWM'de kendi baslayamaz)
        if pwm > 0 and self.out_pwm == 0 and cfg["kick_ms"] > 0 and pwm < 255:
            self.kick_until = now + cfg["kick_ms"] / 1000.0
        out = 255 if (pwm > 0 and now < self.kick_until) else pwm
        self.out_pwm = out

        can_send = self.link.ready and self.link.fan_supported
        if can_send:
            if out != self.last_pwm_sent or now - self.last_send > self.KEEPALIVE:
                if self.link.write_line("F,%d" % out):
                    self.last_pwm_sent = out
                    self.last_send = now
        else:
            self.last_pwm_sent = None
            self.cur_pct = 0.0
            self.out_pwm = 0
        self.status = {"text": text, "level": level, "speed": speed, "pct": self.cur_pct, "pwm": self.out_pwm}

    def run(self):
        while self.running:
            try:
                self.tick(time.monotonic())
            except Exception as e:      # fan hatasi hicbir seyi durdurmasin
                self.status = {"text": "Fan hatası: %s" % e, "level": "bad", "speed": None, "pct": 0, "pwm": 0}
            time.sleep(0.05)
        try:
            self.link.write_line("F,0")
        except Exception:
            pass
