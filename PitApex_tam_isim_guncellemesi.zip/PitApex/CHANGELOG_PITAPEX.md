# PitApex — bu revizyonda yapılanlar

- Mevcut çoklu overlay yönetimi korundu; gerçek telemetri alanlarından dört lastiğin sıcaklık/basınç overlay'i eklendi.
- Hava durumu overlay'i eklendi; mevcut oyun adaptörleri hava tahmini sağlamadığından veri yok uyarısı verir, tahmin uydurmaz.
- Rekor dosyası yazılamazsa bellek içindeki rekor geri alınır ve kullanıcıya hata iletilir.
- Önceki oturum, profil, ayar ve rekor dosyaları değiştirilmedi; mevcut veri dizini PitApex olarak kaldı (eski veriler kaybolmasın diye).

## Henüz tamamlanmayanlar
- Tüm geçerli turlar için ayrı, sınırsız geçmiş; kalıcı tekil tur kimlikleri; tüm oyunlarda geçerlilik doğrulaması.
- Brake Limiter, Gear Up/Down, yeni efekt arayüzü, gerçek hava tahmin adaptörleri.
- Windows'ta oyun, Arduino ve EXE doğrulaması; gerçek dört oyunla entegrasyon ve yük testleri.

Bu revizyon dağıtıma hazır olarak nitelendirilmemelidir.

## Overlay revizyonu (2026-11-18)
- Pedal overlay'i 470x155 varsayılan boyutlu, solda 5/10 saniyelik kırmızı fren/yeşil gaz geçmiş grafiği ve sağda dikey fren/gaz çubukları olacak şekilde yeniden düzenlendi.
- Grafik çizim alanının üst/alt sınırları pedal çubuklarıyla aynı koordinatlara bağlandı.
- Yüzdeler çubukların altında; grafik altında ek gösterge yok.
- Her overlay için ayrı saydamlık (%10-100), genişlik ve yükseklik kontrolleri eklendi. Konum ve ölçüler mevcut overlay_geometry ayarına; saydamlık yeni overlay_opacity anahtarına kaydedilir.
- Grafik yalnızca canlı telemetriyi gösterir; örnek veri üretmez. Geçmiş tamponu seçilen 5/10 saniyeye göre budanır.
- Python compileall ve 116 mevcut unittest başarılı. Windows grafik arayüzü, canlı oyun ve EXE testleri bu ortamda yapılmadı.

## Overlay şeffaflığı ve Araç Durumu görseli (2026-11-19)
**Şeffaflık ayarı neden çalışmıyordu:** arka plan penceresinin alfa değeri gerçekten ayarlanıyordu, ancak üstündeki
etiket/tuval/tam ekran `rect(0,0,bw,bh)` dolgusu ve kartlar opak boyandığı için arkadaki yarı saydam pencere hiç
görünmüyordu; pedal overlay'inde ise alfa kodu hiç çalışmıyordu (`-alpha` sabit 1.0). Ayrıca kaydırıcı etiketi
"saydamlık" olduğu halde değer arttıkça arka plan *daha görünür* oluyordu.
- Kaydırıcı artık gerçekten **saydamlık**: artınca arka plan kaybolur (0–%90; %90'da durur ki pencere bulunamaz hale gelmesin). Yazılar ve göstergeler hiçbir zaman soldurulmaz.
- Ön plan zemini ve kartların içi, arka plan penceresiyle aynı renkte "saydam anahtar"a çevrildi (eski macenta anahtarda yazı kenarlarında pembe halka oluşuyordu).
- Pedal overlay'i de saydamlığı destekler. **%0'da eski tek-pencere yolu aynen korunur**; arka plan penceresi yalnızca saydamlık > %0 iken açılır.
- Saydam modda boş alanlar tıklamayı oyuna geçirdiği için her overlay'in sağ üstüne küçük opak taşıma tutamacı (≡) eklendi.
- Geri uyumluluk: `overlay_opacity` kaydı eski anlamıyla (arka plan görünürlüğü %10–100) durur; arayüz 100 − değer gösterir. Eski kayıtlar bozulmaz.
- Kaydırıcı sürüklenirken diske her adımda yazılmaz (600 ms gecikmeli, kapanışta kesin yazım).

**Araç Durumu:** poligon çizim yerine verilen PitApex GT üstten görseli kullanılır (siyah zemin şeffaflaştırıldı, 5 boyutta
hazır PNG; çalışma anında Pillow gerekmez, dosya açılamazsa eski poligon araç çizilir).
- Gövde bölgeleri ön / arka / sol / sağ / orta, tekerlekler ayrı çerçeve olarak boyanır: **kırmızı = hasarlı, yeşil = sağlam**.
- Kaynak: ACC ve AC `carDamage[5]` (ön, arka, sol, sağ, orta; 0 = hasarsız, eşik 0,1 ham birim), ACC ayrıca `suspensionDamage[4]`.
  Değerlerden biri bile geçersizse tüm hasar verisi atılır. **Oyun hasar vermiyorsa (LMU, iRacing) bölge boyanmaz** ve "Veri yok" yazar; bilinmeyen bölge asla yeşil gösterilmez.
- Alt şeritte ham hasar değerleri gösterilir (yüzde uydurulmaz). Parça Durumu sekmesi değişmedi.
- Görselleri yeniden üretmek / bölge sınırlarını ayarlamak: `py tools/build_car_assets.py` (Pillow, numpy, scipy gerekir).
- 148 otomatik test + 39 maddelik duman testi geçti. **Gerçek Windows'ta tıklama/odak ve oyunla canlı test yapılmadı.**

## Kademeli hasar rengi (2026-11-19)
- Hasar artık ikili (yeşil/kırmızı) değil **kademeli**: hasarsız = yeşil, hasar arttıkça sarı → turuncu, tamamen kırık = kırmızı. Gövde bölgeleri 9 hazır kademeyle (`car_<h>_<bölge>_s0..s8.png`), tekerlek çerçeveleri aynı renk formülüyle (çalışma anında hesaplanır) boyanır.
- Kademe = ham değer / `BODY_DAMAGE_FULL` (gövde) veya `SUSP_DAMAGE_FULL` (süspansiyon), `ui/car_view.py` başında. **Bu "tamamen kırık" tavan değerleri (100) doğrulanmadı**; oyunun gerçek tavanına göre ayarlanmalı (alt şeritte ham değerler görünür).
- Eşiğin (0,1) üstündeki ilk hasar bile en az 1. kademe olur. Veri yoksa bölge yine boyanmaz.
- Sağ üstteki gösterge yeşil→kırmızı geçiş çubuğu oldu; süspansiyon etiketi SAĞLAM / HASARLI / KIRIK.
- Görselleri yeniden üretmek: `py tools/build_car_assets.py` (`STEPS` değişirse `ui/car_view.py` içindeki `STEPS` de aynı olmalı).
- 150 otomatik test geçti. Windows'ta canlı oyunla test yapılmadı.

## Tekerlek/aks kırığı uyarısı ve psi (2026-11-19)
- Süspansiyon hasarı `PULL_WARN_LEVEL` (varsayılan 4/8) ve üstüne çıkınca tekerlek kartında "⚠ SAĞA ÇEKER / SOLA ÇEKER" (ön), "⚠ ARKA KARARSIZ" (arka) yazar; tam kırıkta başına "KIRIK:" eklenir. Üst şeritte özet: "⚠ SAĞ ÖN KIRIK · SAĞA ÇEKER" (birden fazla tekerlek: "N TEKERLEK HASARLI").
- Telemetride gerçek "çekiş" sinyali yok: yön, hasarlı taraftan **tahmin** edilir; eşik doğrulanmadı.
- Lastik basıncı overlay'de artık psi (iç model kPa kalır, gösterimde çevrilir).
- 154 test geçti. Windows'ta canlı oyunla test yapılmadı.

## Lastik sıcaklığı renkleri: kuru/ıslak ayrı profil (2026-11-19)
- Araç Durumu'nda her lastiğin sıcaklığı renklenir (mavi = soğuk, yeşil = ideal, kırmızı = sıcak, arası yumuşak geçiş), durum kelimesi (SOĞUK/İDEAL/SICAK) yazılır ve tekerleğin üstüne sıcaklık rengi şeridi çizilir. Süspansiyon hasarı çerçevesi ayrı kalır.
- Kuru ve ıslak için AYRI dört değer: soğuk altı, ideal en düşük, ideal en yüksek, sıcak üstü. Overlay'ler sekmesi → Araç Durumu → "Lastik sıcaklığı renkleri". Ayarlar `tyre_temp` anahtarıyla kaydedilir; hatalı sıra/değer kaydedilmez ve nedeni yazılır.
- Hangi profilin uygulanacağı oyunun GERÇEK lastik tipinden seçilir (`tyre_wet`): ACC `tyreCompound` ("wet_compound"/"dry_compound"), okunamazsa `rainTyres`; AC bileşik adı; LMU ön lastik bileşik adı (Wet/Intermediate = ıslak). Mod: Otomatik / Hep kuru / Hep ıslak.
- Oyun tip vermiyorsa (iRacing'de okunmuyor) tahmin edilmez; "Oyun tip vermezse" yedek profili (varsayılan Kuru) uygulanır ve üst etiket "(oyun tipi vermiyor)" yazar.
- Varsayılan değerler (kuru 60/80–95/110, ıslak 40/55–75/90 °C) yalnızca başlangıçtır, DOĞRULANMIŞ ideal değerler değildir.
- Sıcaklık kaynağı: ACC/AC çekirdek sıcaklığı, LMU üç ölçümün ortalaması, iRacing mevcut alanlar. Oyunlar arası aynı eşikler geçerli olmayabilir.
- 172 test + 39 maddelik duman testi geçti. Ayar penceresinin Tk widget'ları ve canlı oyun Windows'ta denenmedi (panel mantığı widget'sız test edildi).

## Canlı renkler + saydamlıkta görselin korunması (2026-11-19)
- Hasar renkleri yeniden yapıldı: sabit canlı doygunlukta yeşil → limon → sarı → turuncu → kırmızı. Gövde bölgeleri artık düz yarı saydam boya yerine aracın kendi gölge/parlama detayı korunarak yeniden boyanır (eski ara tonlar çamur/kahve gibi duruyordu). Yeşil/kırmızı sabitleri ve lastik sıcaklığı mavi/yeşil/kırmızısı aynı canlı paletten türetildi; tekerlek kartlarının üstünde sıcaklık rengi çubuğu, vurgu rengi daha parlak turuncu.
- Saydamlık yalnızca arka plan penceresini etkiler (mimari zaten böyleydi: ön plan ASLA soldurulmaz). Bulunan gerçek hata: araç görselinde saydam-anahtar rengine (#151515) birebir denk gelen koyu pikseller (500 px boyutunda ~330 adet) saydamlıkta şeffaf iğne deliği gibi görünebiliyordu; tüm görseller bu renkten arındırıldı ve test eklendi.
- Görsel paketi büyüdü (assets/car ≈ 7,2 MB; 231 dosya).
- Yeniden üretim: `py tools/build_car_assets.py` (Pillow, numpy, scipy). `ui/car_view.py` ile `tools/build_car_assets.py` renk formülü aynı olmalı (test kontrol eder).
- 175 test + 39 maddelik duman testi geçti. Windows'ta gerçek saydamlık görünümü ve oyunla canlı test yapılmadı.
