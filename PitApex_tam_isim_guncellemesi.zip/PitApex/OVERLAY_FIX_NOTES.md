# Overlay düzeltmesi
- Windows'ta arka plan penceresine tıklama ve odak alma engeli eklendi (WS_EX_TRANSPARENT / WS_EX_NOACTIVATE).
- Odak kazanıldığında saydam arka planın ön plan telemetri katmanının arkasında kalması sağlandı.
- Overlay sekme başlıkları siyah/turuncu stile geçirildi; seçili sekme turuncu, yazısı siyah.
- Küçük köşe tutamacı, grafik ve diğer işlevler korundu.
- 116 otomatik test geçti; Windows'ta canlı tıklama testi yapılmadı.
