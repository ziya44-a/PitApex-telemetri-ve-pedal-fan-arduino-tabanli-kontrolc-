// PitApex / Pedal Haptic v3 - Arduino Uno + L293D Motor Shield (Adafruit Motor Shield V1 / AFMotor)
// Komutlar (satir sonu '\n' ile):
//   M<motor>,<guc 0-255>,<frekans x10 Hz>,<darbe orani %>   ornek: M1,200,120,50  (12.0 Hz, %50)
//        frekans 0 = surekli titresim
//   Q<0-3>  motor PWM frekansi (M1+M2 ortak): 0=1kHz 1=2kHz 2=8kHz 3=64kHz
//   F,<0-255>  FAN hizi (M3 veya M4, asagida FAN_MOTOR)   ornek: F,128
//   P  -> "P" cevabi (gecikme olcumu)     V -> "V3" cevabi (kod surumu)
// Motor 1 = FREN, Motor 2 = GAZ. 150 ms komut gelmezse titresim motorlari durur.
// FAN: pedal motorlarindan AYRI zaman asimi vardir (FAN_TIMEOUT_MS). PC surekli F komutu gonderir;
//      USB kopar / program kapanirsa fan FAN_TIMEOUT_MS sonra durur.
// FAN PWM frekansi SABITTIR (~1 kHz, MOTOR34_1KHZ). 64/8 kHz secenekleri Timer0 hizini degistirip
//      millis()/micros() zamanlamasini bozacagi icin BILEREK kullanilmaz. Q komutu fani etkilemez.

#include <AFMotor.h>

#define FW_VERSION 3

// Fan hangi cikista? 3 = M3 (Arduino pin 6), 4 = M4 (Arduino pin 5)
#define FAN_MOTOR 3
#define FAN_TIMEOUT_MS 2000

const uint8_t PWM_CODES[4] = { MOTOR12_1KHZ, MOTOR12_2KHZ, MOTOR12_8KHZ, MOTOR12_64KHZ };

AF_DCMotor motors[2] = { AF_DCMotor(1, MOTOR12_1KHZ), AF_DCMotor(2, MOTOR12_1KHZ) };

// Fan: MOTOR34_1KHZ Timer0 on-bolucusunu Arduino varsayilaniyla ayni birakir (millis/micros bozulmaz)
AF_DCMotor fan(FAN_MOTOR, MOTOR34_1KHZ);
uint8_t       fanSpeed     = 0;
int16_t       lastFanSpeed = -1;
unsigned long lastFanCmd   = 0;

uint8_t  intensity[2]  = {0, 0};
uint16_t freq10[2]     = {0, 0};
uint8_t  duty[2]       = {50, 50};
int16_t  lastSpeed[2]  = {-1, -1};
bool     outputOn[2]   = {false, false};
bool     wasActive[2]  = {false, false};
uint32_t phaseStart[2] = {0, 0};
unsigned long lastCommand = 0;

char buf[32];
uint8_t len = 0;

void applyMotor(uint8_t m) {
  int16_t sp = outputOn[m] ? intensity[m] : 0;
  if (sp != lastSpeed[m]) {
    lastSpeed[m] = sp;
    motors[m].setSpeed(sp);
  }
}

void setPwmCode(uint8_t c) {
  motors[0] = AF_DCMotor(1, PWM_CODES[c]);
  motors[1] = AF_DCMotor(2, PWM_CODES[c]);
  for (uint8_t i = 0; i < 2; i++) {
    motors[i].setSpeed(0);
    motors[i].run(FORWARD);
    lastSpeed[i] = -1;
  }
}

void parseLine() {
  buf[len] = 0;
  if (buf[0] == 'P') { Serial.println('P'); return; }
  if (buf[0] == 'V') { Serial.print('V'); Serial.println(FW_VERSION); return; }
  if (buf[0] == 'Q') {
    int c = atoi(buf + 1);
    if (c >= 0 && c < 4) setPwmCode(c);
    lastCommand = millis();
    return;
  }
  if (buf[0] == 'F') {                       // fan: "F,<0-255>" (pedal zaman asimini yenilemez)
    char* q = strchr(buf, ',');
    int v = atoi(q ? q + 1 : buf + 1);
    fanSpeed = constrain(v, 0, 255);
    lastFanCmd = millis();
    return;
  }
  if (buf[0] != 'M') return;
  int m = buf[1] - '1';
  if (m < 0 || m > 1) return;
  char* p = strchr(buf, ',');
  if (!p) return;
  int s = atoi(p + 1);
  p = strchr(p + 1, ',');
  if (!p) return;
  int f = atoi(p + 1);
  int d = 50;
  p = strchr(p + 1, ',');
  if (p) d = atoi(p + 1);
  intensity[m] = constrain(s, 0, 255);
  freq10[m]    = constrain(f, 0, 1000);
  duty[m]      = constrain(d, 5, 95);
  lastCommand  = millis();
}

void setup() {
  Serial.begin(115200);
  for (uint8_t i = 0; i < 2; i++) {
    motors[i].setSpeed(0);
    motors[i].run(FORWARD);
  }
  fan.setSpeed(0);
  fan.run(FORWARD);
  lastCommand = millis();
  lastFanCmd = millis();
}

void loop() {
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\n') { parseLine(); len = 0; }
    else if (c != '\r' && len < sizeof(buf) - 1) buf[len++] = c;
  }

  if (millis() - lastCommand > 150) { intensity[0] = 0; intensity[1] = 0; }
  if (millis() - lastFanCmd > FAN_TIMEOUT_MS) fanSpeed = 0;   // fan icin ayri guvenlik zaman asimi
  if (fanSpeed != lastFanSpeed) { lastFanSpeed = fanSpeed; fan.setSpeed(fanSpeed); }

  uint32_t nowUs = micros();
  for (uint8_t i = 0; i < 2; i++) {
    if (intensity[i] == 0) {
      outputOn[i] = false;
      wasActive[i] = false;
    } else {
      if (!wasActive[i]) { wasActive[i] = true; phaseStart[i] = nowUs; }  // darbe hep ACIK baslar
      if (freq10[i] == 0) {
        outputOn[i] = true;
      } else {
        uint32_t period = 10000000UL / freq10[i];          // mikrosaniye
        uint32_t onTime = period * duty[i] / 100;
        uint32_t el = nowUs - phaseStart[i];
        if (el >= period) { phaseStart[i] = nowUs; el = 0; }
        outputOn[i] = el < onTime;
      }
    }
    applyMotor(i);
  }
}
