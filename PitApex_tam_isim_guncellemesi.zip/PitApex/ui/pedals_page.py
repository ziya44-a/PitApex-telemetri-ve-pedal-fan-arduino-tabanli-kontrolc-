"""01 - Pedallar sayfasi. Eski PedalHaptic arayuzunun (efektler, motor ince ayari, profiller, canli telemetri)
ayni widget ve ayni ayar mantigiyla tasinmis halidir."""
import json
import time
import tkinter as tk
from tkinter import ttk, messagebox

from core.engine import DEFAULT_MOTORS, DEFAULTS, EFFECTS, MOTOR_CHOICES, PWM_CHOICES
from telemetry.legacy_sources import HINTS, SOURCES

# Efekt detay ayarlari (acilinca gorunur): (alan, etiket, min, maks, bicim, adim)
_POWER = [("intensity", "Motor gücü / şiddet %", 0, 100, "%.0f", 1),
          ("min_pct", "Minimum güç %", 0, 100, "%.0f", 1),
          ("max_pct", "Maksimum güç %", 0, 100, "%.0f", 1)]
_WAVE = [("freq", "Frekans Hz (0=sürekli)", 0, 80, "%.1f", 0.5),
         ("duty", "Darbe oranı %", 5, 95, "%.0f", 1)]
_THR = ("thr", "Aktivasyon eşiği", 0.0, 1.0, "%.2f", 0.01)
_HOLD = ("hold", "Tutma süresi ms", 0, 300, "%.0f", 5)
_SENS_RAMP = ("sens", "Hassasiyet % (50=varsayılan)", 10, 100, "%.0f", 5)
FIELDS = {
    "abs":   _POWER + _WAVE + [_THR, _HOLD],
    "lock":  _POWER + _WAVE + [_THR, _SENS_RAMP, _HOLD],
    "tc":    _POWER + _WAVE + [_THR, _HOLD],
    "slip":  _POWER + _WAVE + [_THR, _SENS_RAMP, _HOLD],
    "rev":   _POWER + _WAVE + [("thr", "Devir eşiği (0-1)", 0.0, 1.0, "%.2f", 0.01), _HOLD],
    "shift": _POWER + _WAVE + [("hold", "Titreşim süresi ms", 0, 300, "%.0f", 5)],
    "blim":  _POWER + _WAVE + [("thr", "Aktivasyon fren %", 10, 99, "%.0f", 1),
                               ("full", "Tam güç fren %", 20, 100, "%.0f", 1),
                               ("hyst", "Histerezis % (kapanma payı)", 0, 30, "%.0f", 1),
                               ("sens", "Hassasiyet % (50=varsayılan)", 10, 100, "%.0f", 5),
                               ("hold", "Tutma süresi ms", 0, 300, "%.0f", 5)],
    "gup":   _POWER + _WAVE + [("hold", "Titreşim süresi ms", 10, 500, "%.0f", 5),
                               ("sens", "Tepki hassasiyeti % (100=anında)", 0, 100, "%.0f", 5)],
    "gdown": _POWER + _WAVE + [("hold", "Titreşim süresi ms", 10, 500, "%.0f", 5),
                               ("sens", "Tepki hassasiyeti % (100=anında)", 0, 100, "%.0f", 5)],
}
HELP = {
    "lock": "Hassasiyet: kayma eşiği aşıldığında şiddetin ne kadar hızlı tam güce çıktığı.",
    "slip": "Hassasiyet: kayma eşiği aşıldığında şiddetin ne kadar hızlı tam güce çıktığı.",
    "blim": "Fren, aktivasyon %'sine ulaşınca başlar; tam güç %'sinde ayarlı gücün üstüne çıkmaz. Titreşim, "
            "aktivasyondan histerezis payı kadar aşağı inene dek sürer (eşikte titrek açılıp kapanmaz).",
    "gup":   "Vites yükselince tek bir titreşim. Düşük hassasiyet, vitesin kararlı kalmasını bekler (N geçişini eler).",
    "gdown": "Vites düşünce tek bir titreşim. Düşük hassasiyet, vitesin kararlı kalmasını bekler (N geçişini eler).",
}
COLUMNS = (("abs", "lock", "blim", "tc"), ("slip", "rev", "shift", "gup", "gdown"))


class PedalsPage(ttk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        self.cfg = app.cfg
        self.engine = app.engine
        self.vars = {}
        self.details = {}
        self._last_saved = None
        self._last_autosave = time.time()
        self.build_ui()
        self.load_settings()
        self._last_saved = self._snapshot()

    # ---------------- arayuz ----------------
    def build_ui(self):
        # sayfa uzun olabilir (acik efektler): kaydirilabilir govde
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=1)
        self.canvas = tk.Canvas(self, highlightthickness=0, bg=self.app.theme.c["bg"])
        sb = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=sb.set)
        self.canvas.grid(row=0, column=0, sticky="nsew")
        sb.grid(row=0, column=1, sticky="ns")
        self.body = ttk.Frame(self.canvas)
        self._win = self.canvas.create_window(0, 0, window=self.body, anchor="nw")
        self.body.columnconfigure(0, weight=1)
        self.body.columnconfigure(1, weight=1)
        self.body.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda e: self.canvas.itemconfigure(self._win, width=e.width))
        self.canvas.bind("<Enter>", lambda e: self.canvas.bind_all("<MouseWheel>", self._wheel))
        self.canvas.bind("<Leave>", lambda e: self.canvas.unbind_all("<MouseWheel>"))
        r = self.body
        gf = ttk.LabelFrame(r, text="Oyun (pedal titreşimi için telemetri kaynağı)")
        gf.grid(row=0, column=0, columnspan=2, sticky="ew", padx=6, pady=4)
        self.src_var = tk.StringVar(value="ACC")
        self.auto_var = tk.BooleanVar(value=True)
        btns = ttk.Frame(gf)
        btns.pack(side="left", padx=2, pady=2)
        for i, name in enumerate(("ACC", "AC", "LMU", "iRacing", "BeamNG", "ETS2")):
            ttk.Radiobutton(btns, text=name, value=name, variable=self.src_var, style="Toolbutton",
                            width=8, command=self.change_source).grid(row=0, column=i, padx=3, pady=2)
        ttk.Checkbutton(gf, text="Otomatik algıla", variable=self.auto_var).pack(side="left", padx=12)

        tel = ttk.LabelFrame(r, text="Canlı telemetri")
        tel.grid(row=1, column=0, columnspan=2, sticky="ew", padx=6, pady=4)
        self.game_lbl = ttk.Label(tel, text="Bekleniyor...")
        self.game_lbl.grid(row=0, column=0, columnspan=4, sticky="w", padx=4)
        self.bars = {}
        for i, (key, text) in enumerate([("gas", "Gaz"), ("brake", "Fren"), ("abs", "ABS"), ("tc", "TC")]):
            ttk.Label(tel, text=text, width=6).grid(row=1 + i, column=0, sticky="w", padx=4)
            pb = ttk.Progressbar(tel, maximum=100, length=220)
            pb.grid(row=1 + i, column=1, padx=4, pady=1)
            self.bars[key] = pb
        self.val_lbl = ttk.Label(tel, text="", justify="left")
        self.val_lbl.grid(row=1, column=2, rowspan=4, padx=14, sticky="w")
        self.ind = {}
        indf = ttk.Frame(tel)
        indf.grid(row=1, column=3, rowspan=4, padx=8)
        c = self.app.theme.c
        for i, (k, info) in enumerate(EFFECTS.items()):
            lb = tk.Label(indf, text=info["name"], width=26, bg=c["ind_off"], fg=c["muted"], anchor="w")
            lb.grid(row=i % 5, column=i // 5, padx=2, pady=1)
            self.ind[k] = lb

        ef = ttk.LabelFrame(r, text="Efektler (kutucukla aç; detaylar açılınca görünür)")
        ef.grid(row=2, column=0, columnspan=2, sticky="ew", padx=6, pady=4)
        ef.columnconfigure(0, weight=1, uniform="eff")
        ef.columnconfigure(1, weight=1, uniform="eff")
        for col, keys in enumerate(COLUMNS):
            stack = ttk.Frame(ef)
            stack.grid(row=0, column=col, sticky="new", padx=4, pady=2)
            for k in keys:
                self.build_effect(stack, k, EFFECTS[k])

        mf = ttk.LabelFrame(r, text="Motor ince ayarı")
        mf.grid(row=3, column=0, columnspan=2, sticky="ew", padx=6, pady=4)
        self.mvars = {"pwm": tk.StringVar(value=PWM_CHOICES[DEFAULT_MOTORS["pwm"]])}
        ttk.Label(mf, text="Motor PWM frekansı (M1+M2 ortak)").grid(row=0, column=0, sticky="w", padx=4)
        ttk.Combobox(mf, textvariable=self.mvars["pwm"], values=PWM_CHOICES, state="readonly",
                     width=22).grid(row=0, column=1, columnspan=2, sticky="w", pady=2)
        for col, (m, label) in enumerate((("1", "Fren motoru (M1)"), ("2", "Gaz motoru (M2)"))):
            fr = ttk.LabelFrame(mf, text=label)
            fr.grid(row=1, column=col * 3, columnspan=3, sticky="ew", padx=4, pady=2)
            self.mvars["min" + m] = tk.DoubleVar(value=DEFAULT_MOTORS["min" + m])
            self.mvars["max" + m] = tk.DoubleVar(value=DEFAULT_MOTORS["max" + m])
            self.slider(fr, 0, "Min güç (0-255)", self.mvars["min" + m], 0, 200, "%.0f", 1)
            self.slider(fr, 1, "Max güç %", self.mvars["max" + m], 20, 100, "%.0f", 1)
        ttk.Label(mf, text="Min güç: motorun dönmeye başladığı en düşük değer. %1 şiddette bile "
                           "dönsün istiyorsan yükselt.", style="Muted.TLabel").grid(
            row=2, column=0, columnspan=6, sticky="w", padx=4)

        pf = ttk.LabelFrame(r, text="Profiller")
        pf.grid(row=4, column=0, columnspan=2, sticky="ew", padx=6, pady=4)
        self.prof_var = tk.StringVar()
        self.prof_box = ttk.Combobox(pf, textvariable=self.prof_var, width=24)
        self.prof_box.grid(row=0, column=0, padx=4, pady=4)
        ttk.Button(pf, text="Kaydet", command=self.save_profile).grid(row=0, column=1, padx=2)
        ttk.Button(pf, text="Yükle", command=self.load_profile).grid(row=0, column=2, padx=2)
        ttk.Button(pf, text="Varsayılana dön", command=self.reset_defaults).grid(row=0, column=3, padx=2)
        self.refresh_profiles()

    def build_effect(self, parent, key, info):
        """Bağımsız kart: kapalıyken yalnız kutucuk + ad; açılınca detaylar aşağı genişler."""
        card = ttk.Frame(parent, relief="solid", borderwidth=1)
        card.pack(fill="x", pady=3)
        card.columnconfigure(0, weight=1)
        v = {}
        for f, dv in DEFAULTS[key].items():
            if f == "enabled":
                v[f] = tk.BooleanVar(value=dv)
            elif f == "motor":
                v[f] = tk.StringVar(value=MOTOR_CHOICES[dv])
            else:
                v[f] = tk.DoubleVar(value=dv)
        self.vars[key] = v
        ttk.Checkbutton(card, text=info["name"], variable=v["enabled"],
                        command=lambda k=key: self.toggle_effect(k)).grid(row=0, column=0, sticky="w", padx=6, pady=3)
        d = ttk.Frame(card)
        d.grid(row=1, column=0, sticky="ew", padx=4, pady=(0, 4))
        self.details[key] = d
        ttk.Label(d, text="Motor").grid(row=0, column=0, sticky="w", padx=4)
        ttk.Combobox(d, textvariable=v["motor"], values=MOTOR_CHOICES, state="readonly",
                     width=18).grid(row=0, column=1, sticky="w", padx=2, pady=2)
        ttk.Button(d, text="Test (1 sn)", command=lambda k=key: self.test_effect(k)).grid(row=0, column=2)
        for i, (f, label, lo, hi, fmt, step) in enumerate(FIELDS[key]):
            self.slider(d, 1 + i, label, v[f], lo, hi, fmt, step)
        if key in HELP:
            ttk.Label(d, text=HELP[key], style="Muted.TLabel", wraplength=340, justify="left").grid(
                row=1 + len(FIELDS[key]), column=0, columnspan=3, sticky="w", padx=4, pady=(2, 0))
        self.update_expand(key)

    def update_expand(self, key=None):
        """Açık efektin detayları görünür, kapalı efekt yalnızca kutucuk + ad olarak kalır."""
        for k in ([key] if key else list(self.details)):
            if self.vars[k]["enabled"].get():
                self.details[k].grid()
            else:
                self.details[k].grid_remove()

    def toggle_effect(self, key):
        """Kutucuk değişti: ayarı hemen motora ilet (kapanan efektin çıkışı bir sonraki turda sıfırlanır)."""
        self.sync_cfg()
        self.update_expand(key)

    def slider(self, parent, row, text, var, lo, hi, fmt, step=1):
        """Kaydırıcı + yanında elle yazılabilen / oklarla ince ayarlanan sayı kutusu."""
        ttk.Label(parent, text=text).grid(row=row, column=0, sticky="w", padx=4)

        def snap(v):
            var.set(round(round(float(v) / step) * step, 3))
        ttk.Scale(parent, from_=lo, to=hi, variable=var, length=150, command=snap).grid(row=row, column=1, padx=2)
        ttk.Spinbox(parent, from_=lo, to=hi, increment=step, textvariable=var, width=6,
                    format=fmt).grid(row=row, column=2, padx=2, pady=1)

    def _wheel(self, e):
        try:
            self.canvas.yview_scroll(int(-e.delta / 120), "units")
        except Exception:
            pass

    # ---------------- kontrol ----------------
    def change_source(self):
        self.auto_var.set(False)  # elle seçince otomatik algılama kapanır
        self.engine.auto = False
        self.engine.pending_source = self.src_var.get()

    def test_effect(self, key):
        self.engine.test = (key, time.perf_counter() + 1.0)

    # ---------------- ayarlar ----------------
    def sync_cfg(self):
        for k, v in self.vars.items():
            for f, var in v.items():
                try:  # kutuya yazarken geçici boş/geçersiz değer olabilir: eskisini koru
                    if f == "motor":
                        val = var.get()
                        self.cfg[k][f] = MOTOR_CHOICES.index(val) if val in MOTOR_CHOICES else DEFAULTS[k]["motor"]
                    else:
                        self.cfg[k][f] = var.get()
                except Exception:
                    pass
        mc = self.cfg["_motors"]
        for f, var in self.mvars.items():
            try:
                if f == "pwm":
                    val = var.get()
                    mc[f] = PWM_CHOICES.index(val) if val in PWM_CHOICES else 0
                else:
                    mc[f] = var.get()
            except Exception:
                pass

    def apply_cfg(self, data):
        self._apply_cfg(data)
        self.update_expand()

    def _apply_cfg(self, data):
        md = data.get("_motors", {}) if isinstance(data, dict) else {}
        for f, var in self.mvars.items():
            try:
                var.set(PWM_CHOICES[int(md[f])] if f == "pwm" else md[f])
            except Exception:
                pass
        for k in EFFECTS:
            for f in DEFAULTS[k]:
                try:
                    if f == "motor":
                        self.vars[k][f].set(MOTOR_CHOICES[int(data[k][f])])
                    else:
                        self.vars[k][f].set(data[k][f])
                except Exception:
                    pass

    def _snapshot(self):
        self.sync_cfg()
        data = json.loads(json.dumps(self.cfg))
        data["_source"] = self.src_var.get()
        data["_auto"] = bool(self.auto_var.get())
        return json.dumps(data, sort_keys=True)

    def load_settings(self):
        data = self.app.pedal_store.load()
        if not data:
            return
        try:
            self.apply_cfg(data)
            if data.get("_source") in SOURCES:
                self.src_var.set(data["_source"])
                self.engine.pending_source = data["_source"]
            if "_auto" in data:
                self.auto_var.set(bool(data["_auto"]))
        except Exception:
            pass

    def save_settings(self, force=False):
        snap = self._snapshot()
        if not force and snap == self._last_saved:
            return
        if self.app.pedal_store.save(json.loads(snap)):
            self._last_saved = snap

    def autosave(self):
        """Elektrik kesintisi/çökme olursa ayar kaybolmasın: değişiklik varsa 10 snde bir yazar."""
        if time.time() - self._last_autosave > 10:
            self._last_autosave = time.time()
            self.save_settings()

    def reset_after_wipe(self):
        self.apply_cfg(DEFAULTS)
        self.prof_var.set("")
        self.refresh_profiles()
        self._last_saved = self._snapshot()      # temizlenen veri kendiliğinden geri yazılmasın

    # ---------------- profiller ----------------
    def refresh_profiles(self):
        self.prof_box["values"] = self.app.profiles.names()

    def save_profile(self):
        name = self.prof_var.get().strip()
        if not name:
            messagebox.showinfo("PitApex", "Profil adı yaz.")
            return
        self.sync_cfg()
        try:
            self.prof_var.set(self.app.profiles.save(name, self.cfg))
        except (ValueError, OSError) as e:
            messagebox.showerror("PitApex", "Profil kaydedilemedi:\n%s" % e)
            return
        self.refresh_profiles()

    def load_profile(self):
        data = self.app.profiles.load(self.prof_var.get().strip())
        if data is None:
            messagebox.showinfo("PitApex", "Profil bulunamadı.")
            return
        self.apply_cfg(data)

    def reset_defaults(self):
        self.apply_cfg(DEFAULTS)

    # ---------------- canlı güncelleme ----------------
    def tick(self, visible):
        """Her turda ayarları motora eşitler; görsel güncelleme sadece sayfa görünürken yapılır."""
        self.sync_cfg()
        e = self.engine
        e.auto = bool(self.auto_var.get())
        if e.auto and e.src.NAME != self.src_var.get() and not e.pending_source:
            self.src_var.set(e.src.NAME)
        self.autosave()
        if not visible:
            return
        s = e.snap
        t = s.get("t") if s else None
        g = e.src.NAME
        if not t:
            self.game_lbl.config(text="%s: veri kaynağı bulunamadı%s" % (g, HINTS.get(g, "")))
        elif not s.get("valid", True):
            self.game_lbl.config(text="%s: veri yapısı uyuşmuyor!" % g)
        elif not s.get("live"):
            self.game_lbl.config(text="%s: bağlı, veri akmıyor (pist/pause?)" % g)
        else:
            self.game_lbl.config(text="%s: canlı veri" % g)

        if t and s.get("live"):
            self.bars["gas"]["value"] = t["gas"] * 100
            self.bars["brake"]["value"] = t["brake"] * 100
            self.bars["abs"]["value"] = min(1, t["abs"]) * 100
            self.bars["tc"]["value"] = min(1, t["tc"]) * 100
            sr = t["slipRatio"]
            self.val_lbl.config(text=(
                "Hız: %.0f km/h  Vites: %s\nKilit (ön): %.2f\nKayma (arka): %.2f\n"
                "ABS: %.2f  TC: %.2f  Devir: %%%.0f" % (t["speed"], t.get("gear", 0), -min(sr[0], sr[1]),
                                                       max(sr[2], sr[3]), t["abs"], t["tc"],
                                                       t.get("rpm_ratio", 0) * 100)))
        else:
            for b in self.bars.values():
                b["value"] = 0
            self.val_lbl.config(text="")
        c = self.app.theme.c
        try:
            self.canvas.configure(bg=c["bg"])
        except Exception:
            pass
        act = s.get("active", {}) if s else {}
        for k, lb in self.ind.items():
            lb.config(bg=c["accent"] if act.get(k) else c["ind_off"],
                      fg=c["on_accent"] if act.get(k) else c["muted"])
