"""PitApex ana penceresi: ust bilgi, ortak Arduino baglantisi, 4 sayfa."""
import copy
import os
import time
import tkinter as tk
from tkinter import ttk, messagebox

from core.engine import DEFAULTS, Engine
from core.session import SessionTracker
from core.telemetry_manager import GAME_NAMES, TelemetryManager
from hardware.arduino import ArduinoLink, list_port_names
from hardware.fan import FanController
from storage.paths import resource_path
from storage.records import RecordStore
from storage.sessions import SessionStore
from storage.settings import PedalSettings, Preferences, Profiles
from ui.dialogs import SettingsWindow
from ui.fan_page import FanPage
from ui.game_info_page import GameInfoPage
from ui.pedals_page import PedalsPage
from ui.records_page import RecordsPage
from ui.overlays_page import OverlaysPage, OverlayManager
from ui.themes import Theme

TABS = ["Pedallar", "Fan", "Oyun Bilgileri", "Kaydedilen Rekorlar", "Overlay Yönetimi"]


class App:
    def __init__(self, root, dm):
        self.root, self.dm = root, dm
        root.title("PitApex")
        self.prefs = Preferences(dm)
        self.theme = Theme(self.prefs.get("theme", "dark"))
        self.theme.apply(root)
        try:                                   # pencere / görev çubuğu simgesi
            root.iconbitmap(resource_path("assets", "pedal.ico"))
        except Exception:
            pass
        self.pedal_store = PedalSettings(dm)
        self.profiles = Profiles(dm)
        self.records = RecordStore(dm)
        self.sessions = SessionStore(dm)

        # --- donanım ve motorlar (hepsi birbirinden bağımsız iş parçacıkları) ---
        self.link = ArduinoLink()
        self.cfg = copy.deepcopy(DEFAULTS)
        self.engine = Engine(self.cfg, self.link)
        self.fan = FanController(self.link, self.engine, lambda: self.fan_page.get_cfg())
        self.tracker = SessionTracker(self.records, self.sessions, GAME_NAMES)
        self.telemetry = TelemetryManager(self.tracker)

        self.overlays = OverlayManager(self)
        self.build_ui()
        self.engine.start()
        self.fan.start()
        self.telemetry.start()
        self.refresh_ports()
        self.n = 0
        self.tick()
        root.protocol("WM_DELETE_WINDOW", self.on_close)

    # ---------------- arayüz ----------------
    def build_ui(self):
        r = self.root
        r.columnconfigure(0, weight=1)
        r.rowconfigure(3, weight=1)

        head = ttk.Frame(r)
        head.grid(row=0, column=0, sticky="ew", padx=10, pady=(8, 2))
        try:
            self.logo = tk.PhotoImage(file=resource_path("assets", "logo_56.png"))
            ttk.Label(head, image=self.logo).pack(side="left")
        except Exception:
            self.logo = None
        ttk.Label(head, text="PitApex", style="Title.TLabel").pack(side="left", padx=10)
        ttk.Label(head, text="Sim racing donanım ve telemetri merkezi", style="Muted.TLabel").pack(side="left", padx=4)
        ttk.Button(head, text="⚙ Ayarlar", command=self.open_settings).pack(side="right")

        tabs = ttk.Frame(r)
        tabs.grid(row=1, column=0, sticky="ew", padx=10, pady=(4, 0))
        self.tab_var = tk.IntVar(value=0)
        for i, name in enumerate(TABS):
            ttk.Radiobutton(tabs, text=name, value=i, variable=self.tab_var, style="Tab.Toolbutton",
                            command=self.show_tab).pack(side="left", padx=(0, 4))

        # ortak Arduino bağlantısı (pedal ve fan aynı portu kullanır)
        top = ttk.LabelFrame(r, text="Arduino bağlantısı (pedal + fan ortak)")
        top.grid(row=2, column=0, sticky="ew", padx=10, pady=6)
        self.port_var = tk.StringVar()
        self.port_box = ttk.Combobox(top, textvariable=self.port_var, width=28, state="readonly")
        self.port_box.grid(row=0, column=0, padx=4, pady=4)
        ttk.Button(top, text="Yenile", command=self.refresh_ports).grid(row=0, column=1, padx=2)
        self.conn_btn = ttk.Button(top, text="Bağlan", command=self.toggle_conn)
        self.conn_btn.grid(row=0, column=2, padx=2)
        self.conn_lbl = ttk.Label(top, text="Bağlı değil", style="Muted.TLabel")
        self.conn_lbl.grid(row=0, column=3, padx=8)
        self.lat_lbl = ttk.Label(top, text="Gecikme: -")
        self.lat_lbl.grid(row=0, column=4, padx=8)
        self.banner = ttk.Label(top, text="", style="Warn.TLabel")
        self.banner.grid(row=1, column=0, columnspan=5, sticky="w", padx=6)

        self.container = ttk.Frame(r)
        self.container.grid(row=3, column=0, sticky="nsew", padx=4, pady=2)
        self.container.columnconfigure(0, weight=1)
        self.container.rowconfigure(0, weight=1)
        self.pedals_page = PedalsPage(self.container, self)
        self.fan_page = FanPage(self.container, self)
        self.info_page = GameInfoPage(self.container, self)
        self.records_page = RecordsPage(self.container, self)
        self.overlays_page = OverlaysPage(self.container, self)
        self.pages = [self.pedals_page, self.fan_page, self.info_page, self.records_page, self.overlays_page]
        for p in self.pages:
            p.grid(row=0, column=0, sticky="nsew")
        last = self.prefs.get("last_tab", 0)
        self.tab_var.set(last if isinstance(last, int) and 0 <= last < len(TABS) else 0)
        self.show_tab()

    def show_tab(self):
        i = self.tab_var.get()
        self.pages[i].tkraise()
        self.current = i
        self.prefs.set("last_tab", i)

    # ---------------- bağlantı ----------------
    def refresh_ports(self):
        names = list_port_names()
        self.port_box["values"] = names
        for n in names:
            if "arduino" in n.lower() or "ch340" in n.lower():
                self.port_var.set(n)
                return
        if names and not self.port_var.get():
            self.port_var.set(names[0])

    def toggle_conn(self):
        if self.link.connected:
            self.engine.disconnect()
            self.conn_btn.config(text="Bağlan")
            return
        sel = self.port_var.get()
        if not sel:
            messagebox.showinfo("PitApex", "Önce bir port seç.")
            return
        try:
            self.engine.connect(sel.split(" ")[0])
            self.conn_btn.config(text="Kes")
        except Exception as e:
            messagebox.showerror("PitApex", "Bağlanılamadı:\n%s\n\nSimHub ya da Arduino IDE "
                                 "Serial Monitor açıksa kapat." % e)

    def update_connection(self):
        L = self.link
        c = self.theme.c
        self.banner.config(text=L.error)
        if L.error and not L.connected:
            self.conn_btn.config(text="Bağlan")
        if L.connected:
            self.conn_btn.config(text="Kes")
            if time.time() < L.ready_at:
                self.conn_lbl.config(text="Arduino hazırlanıyor...", foreground=c["warn"])
            elif L.fw_ok:
                txt = "Bağlı (kod v%s)" % L.fw_version
                if not L.fan_supported:
                    txt += " · fan için v3 kodu gerekli"
                self.conn_lbl.config(text=txt, foreground=c["ok"])
            elif time.time() > L.ready_at + 3.0:
                self.conn_lbl.config(text="Arduino kodu eski/uyumsuz! PedalHaptic.ino'yu yeniden yükle",
                                     foreground=c["warn"])
            else:
                self.conn_lbl.config(text="Bağlı", foreground=c["ok"])
        else:
            self.conn_lbl.config(text="Bağlı değil", foreground=c["muted"])
            self.conn_btn.config(text="Bağlan")
        if L.latency is not None:
            self.lat_lbl.config(text="Seri gecikme: %.1f ms (maks %.1f) | döngü: %d Hz"
                                % (L.latency, L.lat_max, self.engine.hz))
        else:
            self.lat_lbl.config(text="Gecikme: - | döngü: %d Hz" % self.engine.hz)

    # ---------------- tema / ayarlar ----------------
    def set_theme(self, name):
        self.theme.set(name, self.root)
        self.prefs.set("theme", name)

    def open_settings(self):
        SettingsWindow(self.root, self)

    # ---------------- tüm veriyi temizle ----------------
    def wipe_all(self):
        """(başarılı_mı, mesaj). Program dosyalarına dokunmaz; sonra temiz veriyle çalışmaya devam eder."""
        try:
            with self.tracker.lock, self.records.lock, self.sessions.lock:
                self.tracker.reset_all()
                removed, errors = self.dm.wipe_user_data()
                self.records.reset()
                self.sessions.reset()
                self.prefs.reset()
        except Exception as e:
            return False, "Temizleme sırasında hata oluştu:\n%s" % e
        self.pedals_page.reset_after_wipe()
        self.fan_page.reset_after_wipe()
        self.theme.set("dark", self.root)
        self.records_page.refresh(force=True)
        if errors:
            return False, "Bazı dosyalar silinemedi:\n" + "\n".join(errors[:5])
        return True, "Tüm kullanıcı verileri temizlendi. PitApex temiz veriyle çalışmaya devam ediyor."

    # ---------------- döngü ----------------
    def tick(self):
        try:
            self.n += 1
            cur = self.current
            self.pedals_page.tick(cur == 0)
            self.update_connection()
            self.overlays.update()
            if self.n % 6 == 0:                  # ~240 ms: ağır olmayan sayfalar
                self.fan_page.tick(cur == 1)
                self.info_page.tick(cur == 2)
                self.records_page.tick(cur == 3)
        except Exception as e:                   # arayüz hatası hiçbir motoru durdurmasın
            self.banner.config(text="Arayüz hatası: %s" % e)
        self.root.after(40, self.tick)

    def on_close(self):
        try:
            self.pedals_page.save_settings()
            self.fan_page.sync()
            self.fan_page.autosave()
        except Exception:
            pass
        self.overlays.close_all()
        self.fan.running = False
        self.telemetry.stop()
        self.engine.running = False
        time.sleep(0.1)
        self.engine.disconnect()
        try:
            self.engine.src.close()
        except Exception:
            pass
        self.root.destroy()
