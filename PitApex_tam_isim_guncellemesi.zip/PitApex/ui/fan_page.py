"""02 - Fan sayfasi: araç hızına bağlı fan kontrolü (pedal sisteminden bağımsız çalışır)."""
import json
import time
import tkinter as tk
from tkinter import ttk

from hardware.fan import curve_pct, normalized

NO_DATA_CHOICES = ["Fan dursun", "Rölantide kalsın"]

HARDWARE_NOTE = (
    "Donanım notları\n"
    "• Fan, motor shield'in M3 (varsayılan) veya M4 çıkışına bağlanır. Hangisi olduğu firmware/PedalHaptic.ino "
    "içindeki FAN_MOTOR satırıyla belirlenir.\n"
    "• L293D kanal başına yaklaşık 0,6 A sürekli (1,2 A tepe) verebilir. Fan etiketindeki akım bunun altında, "
    "tercihen 0,4 A altında olmalı. 12 V, 0,1-0,3 A'lik 2 veya 3 telli fanlar uygundur. Büyük kasa fanları ve "
    "4 telli PWM fanlar bu çıkışa doğrudan bağlanmamalı; onlar için harici MOSFET sürücü gerekir.\n"
    "• Fan PWM frekansı sabit yaklaşık 1 kHz'dir (değiştirilemez). Bazı fanlar düşük hızda hafif ses çıkarabilir.\n"
    "• Fan ve titreşim motorları aynı motor beslemesini paylaşır; besleme zayıfsa fan çalışırken pedal "
    "titreşimi zayıflayabilir.\n"
    "• Min PWM: fanın kendiliğinden dönmeye başladığı en düşük değerdir. Fan düşük hızda duruyorsa yükselt."
)


class FanPage(ttk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        saved = app.prefs.get("fan", {}) or {}
        c = normalized(saved)
        self.vars = {
            "enabled": tk.BooleanVar(value=c["enabled"]),
            "idle_pct": tk.DoubleVar(value=c["idle_pct"]),
            "mid_speed": tk.DoubleVar(value=c["mid_speed"]),
            "mid_pct": tk.DoubleVar(value=c["mid_pct"]),
            "max_speed": tk.DoubleVar(value=c["max_speed"]),
            "max_pct": tk.DoubleVar(value=c["max_pct"]),
            "min_pwm": tk.DoubleVar(value=c["min_pwm"]),
            "kick_ms": tk.DoubleVar(value=c["kick_ms"]),
            "ramp_up": tk.DoubleVar(value=c["ramp_up"]),
            "ramp_down": tk.DoubleVar(value=c["ramp_down"]),
            "no_data": tk.StringVar(value=NO_DATA_CHOICES[1 if c["no_data"] == "idle" else 0]),
        }
        self.test_var = tk.DoubleVar(value=50)
        self.cfg = c                       # fan ipliği bu SÖZLÜĞÜ okur (tk değişkenlerini değil)
        self._last_saved = json.dumps(c, sort_keys=True)
        self._last_save_t = time.time()
        self.build()

    # ---------------- arayüz ----------------
    def build(self):
        self.columnconfigure(0, weight=1)
        st = ttk.LabelFrame(self, text="Durum")
        st.grid(row=0, column=0, sticky="ew", padx=6, pady=4)
        self.status_lbl = ttk.Label(st, text="", style="Big.TLabel")
        self.status_lbl.grid(row=0, column=0, sticky="w", padx=8, pady=(6, 0))
        self.detail_lbl = ttk.Label(st, text="", style="Muted.TLabel")
        self.detail_lbl.grid(row=1, column=0, sticky="w", padx=8, pady=(0, 6))

        ctl = ttk.LabelFrame(self, text="Kontrol")
        ctl.grid(row=1, column=0, sticky="ew", padx=6, pady=4)
        ttk.Checkbutton(ctl, text="Hıza bağlı fan kontrolü açık", variable=self.vars["enabled"]).grid(
            row=0, column=0, sticky="w", padx=6, pady=4)
        ttk.Label(ctl, text="Telemetri yokken:").grid(row=0, column=1, padx=(24, 4))
        ttk.Combobox(ctl, textvariable=self.vars["no_data"], values=NO_DATA_CHOICES, state="readonly",
                     width=18).grid(row=0, column=2, padx=4)
        ttk.Label(ctl, text="Hız bilgisi, pedal sayfasında seçili/algılanan oyundan gelir; pedal efektleri "
                            "kapalı olsa da fan çalışır.", style="Muted.TLabel").grid(
            row=1, column=0, columnspan=3, sticky="w", padx=6, pady=(0, 4))

        mid = ttk.Frame(self)
        mid.grid(row=2, column=0, sticky="ew")
        mid.columnconfigure(0, weight=1)
        cf = ttk.LabelFrame(mid, text="Hız → fan gücü eğrisi")
        cf.grid(row=0, column=0, sticky="nsew", padx=6, pady=4)
        self.slider(cf, 0, "Rölanti gücü % (0 km/h)", "idle_pct", 0, 100, "%.0f", 1)
        self.slider(cf, 1, "Orta nokta hızı (km/h)", "mid_speed", 10, 500, "%.0f", 5)
        self.slider(cf, 2, "Orta nokta gücü %", "mid_pct", 0, 100, "%.0f", 1)
        self.slider(cf, 3, "Maksimum hız (km/h)", "max_speed", 50, 600, "%.0f", 5)
        self.slider(cf, 4, "Güç sınırı % (en yüksek)", "max_pct", 10, 100, "%.0f", 1)
        self.canvas = tk.Canvas(mid, width=340, height=190, highlightthickness=0, bg=self.app.theme.c["panel"])
        self.canvas.grid(row=0, column=1, padx=6, pady=4, sticky="n")

        ad = ttk.LabelFrame(self, text="İnce ayar")
        ad.grid(row=3, column=0, sticky="ew", padx=6, pady=4)
        self.slider(ad, 0, "Min PWM (0-255)", "min_pwm", 0, 200, "%.0f", 1)
        self.slider(ad, 1, "Kalkış darbesi ms (0=kapalı)", "kick_ms", 0, 2000, "%.0f", 50)
        self.slider(ad, 2, "Artış hızı %/sn", "ramp_up", 5, 500, "%.0f", 5)
        self.slider(ad, 3, "Azalış hızı %/sn", "ramp_down", 5, 500, "%.0f", 5)

        tf = ttk.LabelFrame(self, text="Fan testi (oyun gerekmez)")
        tf.grid(row=4, column=0, sticky="ew", padx=6, pady=4)
        ttk.Label(tf, text="Güç %").grid(row=0, column=0, padx=6)
        ttk.Scale(tf, from_=0, to=100, variable=self.test_var, length=220).grid(row=0, column=1, padx=4, pady=6)
        ttk.Button(tf, text="Test (5 sn)", command=self.start_test).grid(row=0, column=2, padx=4)
        ttk.Button(tf, text="Durdur", command=self.app.fan.stop_test).grid(row=0, column=3, padx=4)

        note = ttk.Label(self, text=HARDWARE_NOTE, style="Muted.TLabel", justify="left", wraplength=900)
        note.grid(row=5, column=0, sticky="w", padx=10, pady=(6, 8))

    def slider(self, parent, row, text, key, lo, hi, fmt, step):
        var = self.vars[key]
        ttk.Label(parent, text=text).grid(row=row, column=0, sticky="w", padx=6)

        def snap(v):
            var.set(round(round(float(v) / step) * step, 3))
        ttk.Scale(parent, from_=lo, to=hi, variable=var, length=190, command=snap).grid(row=row, column=1, padx=4)
        ttk.Spinbox(parent, from_=lo, to=hi, increment=step, textvariable=var, width=7, format=fmt).grid(
            row=row, column=2, padx=4, pady=2)

    def start_test(self):
        try:
            self.app.fan.start_test(float(self.test_var.get()), 5.0)
        except Exception:
            pass

    # ---------------- ayar eşitleme ----------------
    def sync(self):
        raw = {}
        for k, var in self.vars.items():
            try:
                raw[k] = var.get()
            except Exception:
                raw[k] = self.cfg.get(k)          # kutu geçici boşsa eskisini koru
        raw["no_data"] = "idle" if raw.get("no_data") == NO_DATA_CHOICES[1] else "stop"
        self.cfg = normalized(raw)

    def get_cfg(self):
        return self.cfg

    def autosave(self):
        if time.time() - self._last_save_t < 3:
            return
        self._last_save_t = time.time()
        snap = json.dumps(self.cfg, sort_keys=True)
        if snap != self._last_saved:
            self.app.prefs.set("fan", self.cfg)
            self._last_saved = snap

    def reset_after_wipe(self):
        from storage.settings import PREF_DEFAULTS
        c = normalized(PREF_DEFAULTS["fan"])
        for k, v in c.items():
            if k == "no_data":
                self.vars[k].set(NO_DATA_CHOICES[1 if v == "idle" else 0])
            else:
                self.vars[k].set(v)
        self.cfg = c
        self._last_saved = json.dumps(c, sort_keys=True)

    # ---------------- görsel güncelleme ----------------
    def tick(self, visible):
        self.sync()
        self.autosave()
        if not visible:
            return
        s = self.app.fan.status
        self.status_lbl.config(text=s["text"], style={"ok": "Ok.TLabel", "warn": "Warn.TLabel",
                                                       "bad": "Bad.TLabel"}.get(s["level"], "Muted.TLabel"))
        sp = "%.0f km/h" % s["speed"] if s["speed"] is not None else "—"
        self.detail_lbl.config(text="Araç hızı: %s   |   Fan gücü: %%%.0f   |   PWM: %d/255"
                                    % (sp, s["pct"], s["pwm"]))
        self.draw_curve(s["speed"])

    def draw_curve(self, speed):
        cv, c = self.canvas, self.app.theme.c
        cv.configure(bg=c["panel"])
        cv.delete("all")
        w, h, l, b, t, r = 340, 190, 36, 26, 10, 10
        cv.create_line(l, h - b, w - r, h - b, fill=c["muted"])
        cv.create_line(l, t, l, h - b, fill=c["muted"])
        mx = max(self.cfg["max_speed"], 50.0)
        sx = lambda v: l + (w - l - r) * min(v, mx) / mx
        sy = lambda p: (h - b) - (h - b - t) * p / 100.0
        for p in (0, 50, 100):
            cv.create_text(l - 4, sy(p), text="%d" % p, anchor="e", fill=c["muted"], font=("Segoe UI", 8))
            cv.create_line(l, sy(p), w - r, sy(p), fill=c["border"], dash=(2, 4))
        cv.create_text(w - r, h - 10, text="km/h", anchor="e", fill=c["muted"], font=("Segoe UI", 8))
        cv.create_text(l, h - 10, text="0", anchor="w", fill=c["muted"], font=("Segoe UI", 8))
        cv.create_text(w - r - 30, h - 10, text="%d" % mx, anchor="e", fill=c["muted"], font=("Segoe UI", 8))
        pts = []
        for i in range(0, 61):
            v = mx * i / 60.0
            pts += [sx(v), sy(curve_pct(v, self.cfg))]
        cv.create_line(*pts, fill=c["accent"], width=2)
        if speed is not None:
            x, y = sx(speed), sy(curve_pct(speed, self.cfg))
            cv.create_oval(x - 5, y - 5, x + 5, y + 5, fill=c["live"], outline="")
