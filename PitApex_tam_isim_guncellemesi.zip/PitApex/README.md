# PitApex

Pedal titreşimi + hıza bağlı fan + oyun bilgileri + kalıcı rekorlar. Windows, Python 3.

## Çalıştırma
1. `1_kurulum.bat` (pyserial kurar, bir kez)
2. `2_baslat.bat` (uygulamayı açar)
3. İsteğe bağlı: `3_exe_olustur.bat` → tek dosya `PitApex.exe`

**Eski ayarların:** İlk açılışta `ayarlar.json` ve `profiller\` klasörü, PitApex klasörünün yanında ya da yanındaki `PedalHaptic` klasöründe bulunursa `Belgeler\PitApex` altına **kopyalanır** (eskiler silinmez, bir kez yapılır).

## Arduino (ÖNEMLİ)
`firmware/PedalHaptic/PedalHaptic.ino` dosyasını Arduino'ya yeniden yükle (v3). Pedal kodu aynı kaldı, sadece fan eklendi.
Eski v2 kodla pedaller çalışmaya devam eder; yalnızca fan çalışmaz ve arayüz bunu açıkça yazar.

- Fan varsayılan **M3**'te. M4 için `.ino` içinde `#define FAN_MOTOR 4`.
- Fan PWM'i sabit ~1 kHz'dir. 8/64 kHz seçenekleri Timer0'ı değiştirip `millis()/micros()` zamanlamasını bozacağı için bilerek kullanılmadı.
- Fan komutu `F,<0-255>`. Pedal motorlarının 150 ms zaman aşımı fana uygulanmaz; fanın ayrı 2 sn zaman aşımı vardır (USB kopar/program kapanırsa fan durur).
- **Donanım:** L293D kanal başına ~0,6 A sürekli verir. 12 V, 0,1-0,3 A'lik 2-3 telli fan uygundur. Büyük kasa fanları ve 4 telli PWM fanlar doğrudan bağlanmamalı (harici MOSFET gerekir).

## Sayfalar
- **Pedallar:** 9 efekt, her biri bağımsız kutucuklu kart (kapalıyken yalnız ad; açılınca motor gücü, min/max güç, frekans, eşik, süre, hassasiyet açılır). Yeni: **Fren limiter** (eşik + histerezis), **Vites yükseltme / düşürme** (vites değişimi tek olay). Efekt kapanınca çıkışı anında sıfırlanır. Motor ince ayarı ve profiller korunur. Efekt hesabı ve ana döngü eski koddan birebir taşındı.
- **Fan:** rölanti / orta nokta / maksimum hız eğrisi (varsayılan: 0 km/h %25, 150 km/h %50, 300 km/h %100), güç sınırı, min PWM, kalkış darbesi, yumuşatma, test, canlı eğri önizlemesi. Telemetri yokken "dur" ya da "rölantide kal" seçilir. Hız bilgisi pedal motorunun okuduğu oyundan gelir; pedal efektleri kapalıyken de çalışır.
- **Oyun Bilgileri:** ● canlı, ◆ kayıtlı geçmiş, "Veri alınamıyor" olarak üç ayrı görünüm. **Oturum saklama:** oyun kapansa ya da telemetri kesilse son oturumun tüm verileri (araç, pist, turlar, hız, yakıt, lastik...) ◆ olarak ekranda kalır; uygulama yeniden açılınca da son oturum gösterilir. Yeni oturum başlayınca eskisi arşive geçer (silinmez). Telemetri kesintisi oturumu bitirmez; oyun kapanışı bitirir.
- **Kaydedilen Rekorlar:** Oyun → Pist → Araç modeli.
- **⚙ Ayarlar:** tema (siyah/beyaz), veri klasörü, en altta **Tehlikeli İşlemler** (SİL yazma + ikinci onay).

## Veri
`Belgeler\PitApex\` (OneDrive'a taşınmış Belgeler dahil gerçek yolu bulur): `records`, `sessions`, `settings`, `profiles`, `backups`. Atomik yazma (geçici dosya → `fsync` → `os.replace`), 5 dakikada bir en fazla yedek (son 10 tutulur), bozuk dosya silinmeden yan tarafa alınıp yedekten geri yüklenir.
"Tüm verileri temizle" yalnızca bu klasörün içeriğini siler, program dosyalarına dokunmaz.

## Telemetri doğruluk ilkesi
Bir alan oyundan okunamıyorsa, 0 geliyorsa (oyunlar yoksa 0 doldurur), mantık aralığı dışındaysa ya da yapı doğrulanamıyorsa **"Veri alınamıyor"** yazılır. Hiçbir yerde tahmin üretilmez (LMU/iRacing TC-ABS kayma oranından tahmin edilmez).

| | ACC | AC | LMU | iRacing |
|---|---|---|---|---|
| Pist / araç | ✔ | ✔ (layout dahil) | ✔ (araç adı livery içerebilir) | ✔ |
| Tur süresi | ✔ | ✔ | ✔ (iki kaynakla çapraz doğrulama) | ✔ (oyun saatiyle çapraz doğrulama) |
| Sektörler | ✔ doğrulanırsa | ✔ 3 sektörlü pistlerde, doğrulanırsa | ✔ doğrulanırsa | ✘ (oyun vermiyor) |
| Tur geçerliliği | ✔ oyundan | ✘ (pit/şüpheli filtresi) | ✘ (pit filtresi) | ✘ (pit filtresi) |
| Yakıt | ✔ | ✔ | ✔ | ✔ |
| Lastik ısı / basınç | ✔ | ✔ | ✔ | yalnızca pit yolunda |
| Su / yağ | su ✔, yağ ✘ | ✘ / ✘ | ✔ / ✔ | ✔ / ✔ |
| ABS / TC aktivitesi | ✔ / ✔ | ✔ / ✔ | ✘ / ✘ | ✔ / ✘ |
| ABS / TC ayar seviyesi | ✔ / ✔ | ✘ / ✘ | ✘ / ✘ | araç destekliyorsa |

Tur olayları: **tamamlanma** (oyun tur sayacı +1), **sıfırlama** (sayaç geriye gider ya da tur saati aynı sayaçta başa döner: pite dönüş / tur yeniden başlatma) ve **başlangıç** (her olayda yeni, boş tur durumu; eski turun bayrakları, saati, sektörleri taşınmaz). Tur saati hiç sıfırlanmıyorsa (20 dk üstü) o tur "aşırı uzun" sayılıp kaydedilmez.

Rekor yalnızca şu koşullarda yazılır: tur, PitApex tur başında ya da sonrasında açıkken tamamlandı; pit yolu kullanılmadı; oyun geçersiz saymadı; süre oyundan okundu ve çapraz doğrulama geçti. Oyun geçerlilik bilgisi vermiyorsa kayıt **"Doğrulanmamış"** etiketiyle saklanır. Sektör süreleri doğrulanamazsa boş bırakılır (S1+S2+S3, tur süresine ±2 ms uymuyorsa hepsi atılır).

## Gerçek oyunla doğrulanması gerekenler
Buradaki test ortamında oyun ve gerçek Tk yoktu. Bellek yapıları resmi belgelere ve bilinen boyutlara göre yazıldı (LMU yapı boyutları bilinen değerlerle birebir tutuyor), mantık yapay verilerle test edildi, **ama gerçek oyunla ilk kullanımda şunlara bak:**
1. Her oyunda pist/araç adı doğru mu? (rekor anahtarı bunlardır)
2. Bir tur at: tur süresi oyunun gösterdiğiyle aynı mı? Sektörler doğru mu, yoksa "—" mi?
3. Pit çıkış/giriş turu ve geçersiz tur rekora **yazılmıyor** mu?
4. Lastik/yakıt/su değerleri oyun içi göstergeyle uyuşuyor mu? Uyuşmayan alan varsa söyle, o alanı kapatırız.
5. LMU: araç adında yarış numarası/livery varsa aynı araç farklı kayıt olabilir.
6. ACC "Veri yapısı uyuşmuyor" yazarsa ilgili alanlar zaten gizlenir; bana haber ver.

## Testler
```
py -m unittest discover -s tests -t .
```
(116 test: depolama, rekor mantığı, tur/sektör takibi, pedal efektleri (fren limiter, vites yükseltme/düşürme), ACC/AC/iRacing/LMU okuyucuları, fan.)
Sahte Tk duman testi: `set PYTHONPATH=tests\fake_tk` ardından `py tests\smoke_ui.py`.


## PitApex oyun telemetrisi ve overlay'ler

Oyun Bilgileri modülü dört oyunu ayrı adaptörlerle okur: ACC, AC, LMU ve iRacing. Bu sürümde kullanılan kaynaklar UDP değil, oyunların yerel paylaşımlı bellek arayüzleridir: AC/ACC `acpmf_*`, LMU `rFactor2SMMP` ve iRacing `IRSDKMemMapFileName`. Bu nedenle UDP paket boyutu varsayımı yapılmaz; her adaptör kendi bellek başlığını, yapı boyutlarını ve alan sınırlarını doğrular. Desteklenmeyen veya doğrulanamayan alanlar `None` kalır.

Oturumlar oyun kimliği + pist + araç ayrımında saklanır. Oyun değiştiğinde mevcut oturum kapatılıp kaydedilir; diğer oyunun telemetrisi önceki oturuma aktarılmaz. Pedal efekt motoru ve oyun bilgileri telemetri işçisi ayrı iş parçacıklarında çalışır.

`Overlay Yönetimi` sekmesinden hız, pedal, devir/vites ve tur bilgisi pencereleri bağımsız açılabilir; birden fazla overlay aynı anda kullanılabilir. Pencereler sol tuşla taşınır, sağ tıkla kapatılır ve konumları tercih dosyasında saklanır.
