"""Kullanici tercihleri, pedal ayarlari ve profiller (hepsi Belgeler/PitApex altinda)."""
import copy
import os
import threading

from storage.atomic import atomic_write_json, read_json

PREF_DEFAULTS = {
    "version": 1,
    "theme": "dark",
    "last_tab": 0,
    "overlay_geometry": {},
    "fan": {
        "enabled": False,
        "idle_pct": 25,        # 0 km/h (rolanti) fan gucu %
        "mid_speed": 150,      # orta nokta hizi km/h
        "mid_pct": 50,         # orta nokta fan gucu %
        "max_speed": 300,      # bu hizda (ve ustunde) en yuksek guc
        "max_pct": 100,        # fanin ulasabilecegi en yuksek guc % (guc siniri)
        "min_pwm": 60,         # fanin donmeye basladigi en dusuk PWM (0-255)
        "kick_ms": 400,        # duruştan kalkarken tam guc suresi
        "ramp_up": 60,         # % / saniye artis hizi
        "ramp_down": 30,       # % / saniye azalis hizi
        "no_data": "stop",     # telemetri yokken: "stop" | "idle"
    },
}


def _deep_merge(base, over):
    out = copy.deepcopy(base)
    if isinstance(over, dict):
        for k, v in over.items():
            if isinstance(v, dict) and isinstance(out.get(k), dict):
                out[k] = _deep_merge(out[k], v)
            else:
                out[k] = v
    return out


class Preferences:
    def __init__(self, dm):
        self.dm = dm
        self.path = dm.path("settings", "preferences.json")
        self.lock = threading.RLock()
        self.status = "ok"
        data, self.status = read_json(self.path, dm.backup_dir, None, lambda d: isinstance(d, dict))
        self.data = _deep_merge(PREF_DEFAULTS, data or {})

    def get(self, key, default=None):
        with self.lock:
            return copy.deepcopy(self.data.get(key, default))

    def set(self, key, value):
        with self.lock:
            self.data[key] = copy.deepcopy(value)
            self.save()

    def save(self):
        with self.lock:
            try:
                atomic_write_json(self.path, self.data, self.dm.backup_dir)
            except OSError:
                self.status = "write_error"

    def reset(self):
        with self.lock:
            self.data = copy.deepcopy(PREF_DEFAULTS)


class PedalSettings:
    """Eski ayarlar.json ile ayni icerik (efektler, _motors, _source, _auto)."""

    def __init__(self, dm):
        self.dm = dm
        self.path = dm.path("settings", "pedal_settings.json")

    def load(self):
        data, status = read_json(self.path, self.dm.backup_dir, None, lambda d: isinstance(d, dict))
        return data

    def save(self, data):
        try:
            atomic_write_json(self.path, data, self.dm.backup_dir)
            return True
        except OSError:
            return False


class Profiles:
    def __init__(self, dm):
        self.dm = dm
        self.dir = dm.path("profiles")

    @staticmethod
    def safe_name(name):
        return "".join(ch for ch in name if ch.isalnum() or ch in " -_").strip()

    def names(self):
        os.makedirs(self.dir, exist_ok=True)
        return sorted(f[:-5] for f in os.listdir(self.dir) if f.endswith(".json"))

    def save(self, name, data):
        safe = self.safe_name(name)
        if not safe:
            raise ValueError("gecersiz profil adi")
        atomic_write_json(os.path.join(self.dir, safe + ".json"), data, None)
        return safe

    def load(self, name):
        safe = self.safe_name(name)
        data, status = read_json(os.path.join(self.dir, safe + ".json"), None, None,
                                 lambda d: isinstance(d, dict))
        return data
