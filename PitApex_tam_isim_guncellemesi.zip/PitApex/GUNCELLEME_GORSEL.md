> **GÜNCEL DURUM (2026-11-19):** Bu not eskidir. Araç Durumu artık assets/car altındaki hazır PNG görselleri tk.PhotoImage ile kullanır (çalışma anında Pillow gerekmez; açılamazsa poligon araç çizilir) ve hasar bölgeleri gerçek telemetriye bağlıdır. Ayrıntı: CHANGELOG_PITAPEX.md

Araç Durumu: kaynak görsel assets/gt3_top_pitapex.png. Pillow gerekir. Pedal overlay koduna dokunulmadı. Sağdaki parça verileri telemetri alanı mevcutsa ham değer olarak gösterilir, sahte yüzde üretilmez. Bölgesel hasar katmanı henüz gerçek telemetriye bağlanmadı. Windows canlı test yapılmadı.
