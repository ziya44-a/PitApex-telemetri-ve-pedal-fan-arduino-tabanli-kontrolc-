# Overlay birleştirme notları

- Temel proje: PitApex_yeniden_paketlenmis(1).zip (çalıştığı bildirilen overlay motoru).
- PitApex_overlay.zip dosyasındaki ayrı Pedal/Hava/Lastik sekme yaklaşımı yeni sekmeli yönetim ekranına taşındı.
- Çalışan overlay motoru korunmuştur; hava, lastik, pedal, hız, RPM ve tur sekmeleri bulunur.
- Eski overlay paketindeki bağımsız pencere motoru doğrudan aktarılmadı; iki motorun çakışması önlendi.
- Sağ alt boyutlandırma tutamacı 7 puntoya küçültüldü.
- Sözdizimi ve ZIP bütünlüğü kontrol edildi; Windows/oyun üzerinde canlı test yapılmadı.
